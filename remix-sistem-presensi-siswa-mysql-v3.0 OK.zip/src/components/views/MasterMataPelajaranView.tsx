import React, { useState, useRef, useMemo } from 'react';
import * as XLSX from 'xlsx';
import {
  BookOpen,
  Calendar,
  Clock,
  Plus,
  Search,
  Edit,
  Trash2,
  FileSpreadsheet,
  Download,
  ArrowUpDown,
  Users,
  CheckCircle2,
  ShieldAlert,
  GraduationCap,
  Sparkles,
  LayoutGrid,
  List,
  Layers,
  Tag,
  Award,
  Hash,
  BookmarkPlus,
  SlidersHorizontal,
  Sun,
  Sunset,
} from 'lucide-react';
import { AppData, JadwalMengajarGuru, MataPelajaran, UserSession, WaliKelas, Kelas } from '../../types';
import { Pagination } from '../Pagination';
import { PageHeader } from '../common/UIComponents';
import { HARI_LIST, addAuditLog } from '../../utils/helpers';
import { DEFAULT_MATA_PELAJARAN } from '../../data/initialData';

interface MasterMataPelajaranViewProps {
  appData: AppData;
  currentUser: UserSession;
  readOnly?: boolean;
  onUpdateAppData: (updated: AppData) => void;
  onOpenModal: (title: string, content: React.ReactNode) => void;
  onCloseModal: () => void;
  onConfirmModal: (
    title: string,
    message: string,
    type: 'danger' | 'warning' | 'info' | 'emerald',
    onConfirm: () => void
  ) => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'warning' | 'info') => void;
}

const MAPEL_KATEGORI_OPTIONS: Array<NonNullable<MataPelajaran['kategori']>> = [
  'Kelompok A (Nasional)',
  'Kelompok B (Kewilayahan)',
  'Kelompok C (Kejuruan/Peminatan)',
  'Muatan Lokal',
  'Bimbingan Konseling',
  'Umum',
];

const TINGKAT_OPTIONS: Array<NonNullable<MataPelajaran['tingkat']>> = [
  'Semua Tingkat',
  'X',
  'XI',
  'XII',
];

export const MasterMataPelajaranView: React.FC<MasterMataPelajaranViewProps> = ({
  appData,
  currentUser,
  readOnly = false,
  onUpdateAppData,
  onOpenModal,
  onCloseModal,
  onConfirmModal,
  onShowToast,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mapelCatalogFileInputRef = useRef<HTMLInputElement>(null);

  // Active Tab: 'katalog' (Master Mapel) vs 'plotting' (Jadwal & Plotting Mengajar)
  const [activeTab, setActiveTab] = useState<'katalog' | 'plotting'>('katalog');

  // Master Mapel List
  const mapelList: MataPelajaran[] = useMemo(() => {
    return appData.mataPelajaran || DEFAULT_MATA_PELAJARAN;
  }, [appData.mataPelajaran]);

  // Schedules List
  const jadwalList: JadwalMengajarGuru[] = useMemo(() => {
    return appData.jadwalMengajar || [];
  }, [appData.jadwalMengajar]);

  const guruList: WaliKelas[] = appData.waliKelas || [];
  const kelasList: Kelas[] = appData.kelas || [];

  /* =========================================================================
     TAB 1: MASTER KATALOG MATA PELAJARAN STATES & LOGIC
     ========================================================================= */
  const [mapelViewMode, setMapelViewMode] = useState<'list' | 'grid'>('list');
  const [mapelSearch, setMapelSearch] = useState('');
  const [mapelFilterKategori, setMapelFilterKategori] = useState<string>('semua');
  const [mapelFilterTingkat, setMapelFilterTingkat] = useState<string>('semua');
  const [mapelSortField, setMapelSortField] = useState<'kode' | 'nama' | 'kategori' | 'alokasiJp'>('kode');
  const [mapelSortDirection, setMapelSortDirection] = useState<'asc' | 'desc'>('asc');
  const [mapelPage, setMapelPage] = useState(1);
  const [mapelPageSize, setMapelPageSize] = useState(10);

  const filteredMapel = useMemo(() => {
    return mapelList.filter((m) => {
      const q = mapelSearch.toLowerCase().trim();
      const matchSearch =
        !q ||
        m.kode.toLowerCase().includes(q) ||
        m.nama.toLowerCase().includes(q) ||
        (m.deskripsi && m.deskripsi.toLowerCase().includes(q)) ||
        (m.jurusanNama && m.jurusanNama.toLowerCase().includes(q));

      const matchKategori =
        mapelFilterKategori === 'semua' || m.kategori === mapelFilterKategori;

      const matchTingkat =
        mapelFilterTingkat === 'semua' ||
        m.tingkat === mapelFilterTingkat ||
        m.tingkat === 'Semua Tingkat';

      return matchSearch && matchKategori && matchTingkat;
    });
  }, [mapelList, mapelSearch, mapelFilterKategori, mapelFilterTingkat]);

  const sortedMapel = useMemo(() => {
    return [...filteredMapel].sort((a, b) => {
      let cmp = 0;
      if (mapelSortField === 'kode') {
        cmp = a.kode.localeCompare(b.kode, undefined, { numeric: true });
      } else if (mapelSortField === 'nama') {
        cmp = a.nama.localeCompare(b.nama, undefined, { numeric: true });
      } else if (mapelSortField === 'kategori') {
        cmp = (a.kategori || '').localeCompare(b.kategori || '');
      } else if (mapelSortField === 'alokasiJp') {
        cmp = (a.alokasiJp || 0) - (b.alokasiJp || 0);
      }
      return mapelSortDirection === 'asc' ? cmp : -cmp;
    });
  }, [filteredMapel, mapelSortField, mapelSortDirection]);

  const mapelTotalPages = Math.ceil(sortedMapel.length / mapelPageSize) || 1;
  const mapelStartIdx = (mapelPage - 1) * mapelPageSize;
  const pagedMapel = sortedMapel.slice(mapelStartIdx, mapelStartIdx + mapelPageSize);

  const handleMapelSort = (field: 'kode' | 'nama' | 'kategori' | 'alokasiJp') => {
    if (mapelSortField === field) {
      setMapelSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setMapelSortField(field);
      setMapelSortDirection('asc');
    }
  };

  // Open Form Modal (Add / Edit Master Mapel)
  const handleOpenMasterMapelModal = (itemToEdit?: MataPelajaran) => {
    if (readOnly) return;

    let initialKode = itemToEdit?.kode || '';
    let initialNama = itemToEdit?.nama || '';
    let initialKategori = itemToEdit?.kategori || 'Kelompok A (Nasional)';
    let initialTingkat = itemToEdit?.tingkat || 'Semua Tingkat';
    let initialJurusanNama = itemToEdit?.jurusanNama || '';
    let initialAlokasiJp = itemToEdit?.alokasiJp || 4;
    let initialKkm = itemToEdit?.kkm || 75;
    let initialDeskripsi = itemToEdit?.deskripsi || '';

    const FormModal: React.FC = () => {
      const [kode, setKode] = useState(initialKode);
      const [nama, setNama] = useState(initialNama);
      const [kategori, setKategori] = useState<MataPelajaran['kategori']>(initialKategori);
      const [tingkat, setTingkat] = useState<MataPelajaran['tingkat']>(initialTingkat);
      const [jurusanNama, setJurusanNama] = useState(initialJurusanNama);
      const [alokasiJp, setAlokasiJp] = useState(initialAlokasiJp);
      const [kkm, setKkm] = useState(initialKkm);
      const [deskripsi, setDeskripsi] = useState(initialDeskripsi);
      const [err, setErr] = useState('');

      const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        setErr('');

        if (!kode.trim()) {
          setErr('Kode Mata Pelajaran wajib diisi (misal: MAT-01, RPL-PW).');
          return;
        }
        if (!nama.trim()) {
          setErr('Nama Mata Pelajaran wajib diisi.');
          return;
        }

        // Duplicate code check
        const currentMList = appData.mataPelajaran || DEFAULT_MATA_PELAJARAN;
        const isDuplicate = currentMList.some(
          (m) =>
            m.kode.trim().toLowerCase() === kode.trim().toLowerCase() &&
            (!itemToEdit || m.id !== itemToEdit.id)
        );
        if (isDuplicate) {
          setErr(`Kode Mapel "${kode.trim().toUpperCase()}" sudah digunakan pada mapel lain.`);
          return;
        }

        const newMapelItem: MataPelajaran = {
          id: itemToEdit ? itemToEdit.id : `MP_${Date.now()}`,
          kode: kode.trim().toUpperCase(),
          nama: nama.trim(),
          kategori: kategori,
          tingkat: tingkat,
          jurusanNama: jurusanNama.trim() || undefined,
          alokasiJp: Number(alokasiJp) || 0,
          kkm: Number(kkm) || 75,
          deskripsi: deskripsi.trim() || undefined,
        };

        let updatedList: MataPelajaran[];
        if (itemToEdit) {
          updatedList = currentMList.map((m) => (m.id === itemToEdit.id ? newMapelItem : m));
        } else {
          updatedList = [newMapelItem, ...currentMList];
        }

        const updatedAppData = addAuditLog(
          { ...appData, mataPelajaran: updatedList },
          itemToEdit ? 'Edit Master Mapel' : 'Tambah Master Mapel',
          `${itemToEdit ? 'Mengubah' : 'Menambahkan'} master mata pelajaran ${nama.trim()} (${kode.trim().toUpperCase()})`
        );

        onUpdateAppData(updatedAppData);
        onCloseModal();
        onShowToast(
          itemToEdit
            ? `Mata Pelajaran ${nama.trim()} berhasil diperbarui!`
            : `Mata Pelajaran ${nama.trim()} berhasil ditambahkan ke Katalog Master!`,
          'success'
        );
      };

      return (
        <form onSubmit={handleSave} className="space-y-4 text-slate-800 dark:text-slate-100">
          {err && (
            <div className="p-3 text-xs rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 font-semibold flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{err}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-blue-600" />
                <span>Kode Mapel</span> <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={kode}
                onChange={(e) => setKode(e.target.value)}
                placeholder="misal: RPL-PWPB"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono font-bold uppercase focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                <span>Nama Mata Pelajaran</span> <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                placeholder="misal: Pemrograman Web & Perangkat Bergerak"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-purple-600" />
                <span>Kelompok / Kategori</span>
              </label>
              <select
                value={kategori}
                onChange={(e) => setKategori(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
              >
                {MAPEL_KATEGORI_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-amber-600" />
                <span>Tingkat Kelas Sasaran</span>
              </label>
              <select
                value={tingkat}
                onChange={(e) => setTingkat(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
              >
                {TINGKAT_OPTIONS.map((t) => (
                  <option key={t} value={t}>
                    {t === 'Semua Tingkat' ? 'Semua Tingkat (X, XI, XII)' : `Khusus Kelas ${t}`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                <span>Alokasi (JP/Minggu)</span>
              </label>
              <input
                type="number"
                min="1"
                max="24"
                value={alokasiJp}
                onChange={(e) => setAlokasiJp(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-center font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-amber-500" />
                <span>KKM Standar</span>
              </label>
              <input
                type="number"
                min="50"
                max="100"
                value={kkm}
                onChange={(e) => setKkm(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-center font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Jurusan (Opsional)
              </label>
              <input
                type="text"
                value={jurusanNama}
                onChange={(e) => setJurusanNama(e.target.value)}
                placeholder="misal: RPL, TKJ, DKV"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Deskripsi & Silabus Ringkas (Opsional)
            </label>
            <textarea
              rows={2}
              value={deskripsi}
              onChange={(e) => setDeskripsi(e.target.value)}
              placeholder="Deskripsi ringkas materi pokok atau capaian pembelajaran..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onCloseModal}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{itemToEdit ? 'Simpan Perubahan' : 'Simpan Master Mapel'}</span>
            </button>
          </div>
        </form>
      );
    };

    onOpenModal(
      itemToEdit ? `Edit Master Mapel: ${itemToEdit.nama}` : 'Tambah Master Mata Pelajaran Baru',
      <FormModal />
    );
  };

  // Delete Master Mapel
  const handleDeleteMasterMapel = (item: MataPelajaran) => {
    if (readOnly) return;
    onConfirmModal(
      'Hapus Master Mata Pelajaran',
      `Apakah Anda yakin ingin menghapus "${item.nama}" (${item.kode}) dari Katalog Master Mapel?`,
      'danger',
      () => {
        const currentList = appData.mataPelajaran || DEFAULT_MATA_PELAJARAN;
        const updatedList = currentList.filter((m) => m.id !== item.id);
        const updatedAppData = addAuditLog(
          { ...appData, mataPelajaran: updatedList },
          'Hapus Master Mapel',
          `Menghapus master mata pelajaran ${item.nama} (${item.kode})`
        );
        onUpdateAppData(updatedAppData);
        onShowToast(`Mata pelajaran ${item.nama} berhasil dihapus dari katalog master.`, 'success');
      }
    );
  };

  // Delete All Master Mapel Catalog
  const handleDeleteAllMasterMapel = () => {
    if (readOnly || mapelList.length === 0) return;
    onConfirmModal(
      'Hapus SEMUA Master Mata Pelajaran',
      `PERINGATAN: Apakah Anda yakin ingin menghapus SEMUA data katalog mata pelajaran (${mapelList.length} mapel)? Tindakan ini akan mengosongkan seluruh daftar mata pelajaran baku dan tidak dapat dibatalkan.`,
      'danger',
      () => {
        const updatedAppData = addAuditLog(
          { ...appData, mataPelajaran: [] },
          'Hapus Semua Master Mapel',
          `Menghapus seluruh katalog master mata pelajaran (${mapelList.length} mapel).`
        );
        onUpdateAppData(updatedAppData);
        onShowToast('Semua data master mata pelajaran berhasil dihapus.', 'success');
      }
    );
  };

  // Export Master Mapel Catalog
  const handleExportMapelCatalog = () => {
    const dataToExport = sortedMapel.map((m, idx) => ({
      NO: idx + 1,
      KODE_MAPEL: m.kode,
      NAMA_MATA_PELAJARAN: m.nama,
      KELOMPOK_KATEGORI: m.kategori || 'Umum',
      TINGKAT_KELAS: m.tingkat || 'Semua Tingkat',
      JURUSAN: m.jurusanNama || 'Semua Jurusan',
      ALOKASI_JP: m.alokasiJp || 4,
      KKM: m.kkm || 75,
      DESKRIPSI_SILABUS: m.deskripsi || '-',
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    ws['!cols'] = [
      { wch: 5 },  // NO
      { wch: 15 }, // KODE_MAPEL
      { wch: 35 }, // NAMA_MATA_PELAJARAN
      { wch: 28 }, // KELOMPOK_KATEGORI
      { wch: 16 }, // TINGKAT_KELAS
      { wch: 22 }, // JURUSAN
      { wch: 12 }, // ALOKASI_JP
      { wch: 8 },  // KKM
      { wch: 45 }, // DESKRIPSI_SILABUS
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Katalog Mata Pelajaran');
    XLSX.writeFile(wb, `Katalog_Master_Mata_Pelajaran_${new Date().toISOString().slice(0, 10)}.xlsx`);
    onShowToast('Katalog Master Mata Pelajaran berhasil diexport ke Excel!', 'success');
  };

  // Download Template Master Mapel
  const handleDownloadMapelCatalogTemplate = () => {
    const templateData = [
      {
        KODE_MAPEL: 'RPL-PWPB',
        NAMA_MATA_PELAJARAN: 'Pemrograman Web & Perangkat Bergerak',
        KELOMPOK_KATEGORI: 'Kelompok C (Kejuruan/Peminatan)',
        TINGKAT_KELAS: 'XI',
        JURUSAN: 'Rekayasa Perangkat Lunak (RPL)',
        ALOKASI_JP: 6,
        KKM: 78,
        DESKRIPSI_SILABUS: 'Materi HTML5, CSS3, JavaScript, React, REST API, dan Mobile Apps.',
      },
      {
        KODE_MAPEL: 'UM-MAT',
        NAMA_MATA_PELAJARAN: 'Matematika Wajib',
        KELOMPOK_KATEGORI: 'Kelompok A (Nasional)',
        TINGKAT_KELAS: 'Semua Tingkat',
        JURUSAN: 'Semua Jurusan',
        ALOKASI_JP: 4,
        KKM: 75,
        DESKRIPSI_SILABUS: 'Aljabar, Trigonometri, Matriks, Barisan & Deret, Kalkulus.',
      },
      {
        KODE_MAPEL: 'TKJ-ASJ',
        NAMA_MATA_PELAJARAN: 'Administrasi Sistem Jaringan',
        KELOMPOK_KATEGORI: 'Kelompok C (Kejuruan/Peminatan)',
        TINGKAT_KELAS: 'XI',
        JURUSAN: 'Teknik Komputer dan Jaringan (TKJ)',
        ALOKASI_JP: 4,
        KKM: 75,
        DESKRIPSI_SILABUS: 'Instalasi Server Linux, DHCP, DNS, Web Server, dan FTP Server.',
      },
    ];

    const ws = XLSX.utils.json_to_sheet(templateData);
    ws['!cols'] = [
      { wch: 15 },
      { wch: 35 },
      { wch: 28 },
      { wch: 16 },
      { wch: 25 },
      { wch: 12 },
      { wch: 8 },
      { wch: 45 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template Master Mapel');
    XLSX.writeFile(wb, 'Template_Import_Master_Mata_Pelajaran.xlsx');
    onShowToast('Template Excel Master Mata Pelajaran berhasil diunduh!', 'info');
  };

  // Import Master Mapel Catalog
  const handleImportMapelCatalog = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json<any>(ws);

        if (!data || data.length === 0) {
          onShowToast('File Excel kosong atau format tidak sesuai.', 'error');
          return;
        }

        let addedCount = 0;
        let updatedCount = 0;
        const currentMList = [...(appData.mataPelajaran || DEFAULT_MATA_PELAJARAN)];

        data.forEach((row, index) => {
          const rawNama = String(
            row.NAMA_MATA_PELAJARAN || row.NAMA_MAPEL || row.Nama_Mata_Pelajaran || row.MATA_PELAJARAN || ''
          ).trim();
          if (!rawNama) return;

          let rawKode = String(
            row.KODE_MAPEL || row.KODE || row.Kode_Mapel || row.KODE_PELAJARAN || ''
          ).trim().toUpperCase();

          if (!rawKode) {
            rawKode = `MP-${rawNama.slice(0, 3).toUpperCase()}-${index + 1}`;
          }

          const rawKategori = String(row.KELOMPOK_KATEGORI || row.KATEGORI || row.KELOMPOK || 'Umum').trim();
          const rawTingkat = String(row.TINGKAT_KELAS || row.TINGKAT || 'Semua Tingkat').trim();
          const rawJurusan = String(row.JURUSAN || '').trim();
          const rawAlokasiJp = Number(row.ALOKASI_JP || row.JP || 4);
          const rawKkm = Number(row.KKM || 75);
          const rawDeskripsi = String(row.DESKRIPSI_SILABUS || row.DESKRIPSI || '').trim();

          const existingIdx = currentMList.findIndex(
            (m) =>
              m.kode.trim().toLowerCase() === rawKode.toLowerCase() ||
              m.nama.trim().toLowerCase() === rawNama.toLowerCase()
          );

          if (existingIdx >= 0) {
            currentMList[existingIdx] = {
              ...currentMList[existingIdx],
              nama: rawNama,
              kategori: rawKategori as any,
              tingkat: rawTingkat as any,
              jurusanNama: rawJurusan || undefined,
              alokasiJp: rawAlokasiJp,
              kkm: rawKkm,
              deskripsi: rawDeskripsi || undefined,
            };
            updatedCount++;
          } else {
            currentMList.push({
              id: `MP_IMP_${Date.now()}_${index}`,
              kode: rawKode,
              nama: rawNama,
              kategori: rawKategori as any,
              tingkat: rawTingkat as any,
              jurusanNama: rawJurusan || undefined,
              alokasiJp: rawAlokasiJp,
              kkm: rawKkm,
              deskripsi: rawDeskripsi || undefined,
            });
            addedCount++;
          }
        });

        const updatedAppData = addAuditLog(
          { ...appData, mataPelajaran: currentMList },
          'Import Master Mapel',
          `Import Katalog Master Mapel: ${addedCount} baru, ${updatedCount} diperbarui.`
        );
        onUpdateAppData(updatedAppData);

        onShowToast(
          `Import Katalog Selesai! ${addedCount} mapel baru ditambahkan, ${updatedCount} diperbarui.`,
          'success'
        );
      } catch (err: any) {
        onShowToast(`Gagal meng-import katalog mapel: ${err.message}`, 'error');
      } finally {
        if (mapelCatalogFileInputRef.current) mapelCatalogFileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  /* =========================================================================
     TAB 2: PLOTTING JADWAL & ALOKASI MENGAJAR STATES & LOGIC
     ========================================================================= */
  const [searchTerm, setSearchTerm] = useState('');
  const [filterHari, setFilterHari] = useState<string>('semua');
  const [filterKelas, setFilterKelas] = useState<string>('semua');
  const [filterGuru, setFilterGuru] = useState<string>('semua');
  const [filterShift, setFilterShift] = useState<string>('semua');
  const [viewMode, setViewMode] = useState<'table' | 'byDay'>('table');
  const [sortField, setSortField] = useState<'mataPelajaran' | 'guruNama' | 'kelasNama' | 'hari' | 'jamMulai' | 'shift'>('hari');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const getScheduleShift = (j: { shift?: string; jamMulai?: string }): string => {
    if (j.shift && j.shift.trim()) return j.shift.trim();
    const startHour = parseInt((j.jamMulai || '07:30').split(':')[0], 10);
    if (!isNaN(startHour) && startHour >= 12) return 'Siang';
    return 'Pagi';
  };

  const filteredJadwal = useMemo(() => {
    return jadwalList.filter((j) => {
      const q = searchTerm.toLowerCase().trim();
      const matchSearch =
        !q ||
        j.mataPelajaran.toLowerCase().includes(q) ||
        j.guruNama.toLowerCase().includes(q) ||
        j.kelasNama.toLowerCase().includes(q) ||
        (j.catatan && j.catatan.toLowerCase().includes(q));

      const matchHari = filterHari === 'semua' || j.hari.toLowerCase() === filterHari.toLowerCase();
      const matchKelas = filterKelas === 'semua' || j.kelasId === filterKelas || j.kelasNama.toLowerCase() === filterKelas.toLowerCase();
      const matchGuru = filterGuru === 'semua' || j.guruUsername === filterGuru || j.guruNama.toLowerCase() === filterGuru.toLowerCase();
      const matchShift = filterShift === 'semua' || getScheduleShift(j).toLowerCase() === filterShift.toLowerCase();

      return matchSearch && matchHari && matchKelas && matchGuru && matchShift;
    });
  }, [jadwalList, searchTerm, filterHari, filterKelas, filterGuru, filterShift]);

  const sortedJadwal = useMemo(() => {
    const hariOrder: Record<string, number> = {
      senin: 1,
      selasa: 2,
      rabu: 3,
      kamis: 4,
      jumat: 5,
      sabtu: 6,
      minggu: 7,
    };

    return [...filteredJadwal].sort((a, b) => {
      let cmp = 0;
      if (sortField === 'hari') {
        const orderA = hariOrder[a.hari?.toLowerCase()] || 99;
        const orderB = hariOrder[b.hari?.toLowerCase()] || 99;
        cmp = orderA - orderB;
        if (cmp === 0) {
          cmp = (a.jamMulai || '').localeCompare(b.jamMulai || '');
        }
      } else if (sortField === 'mataPelajaran') {
        cmp = a.mataPelajaran.localeCompare(b.mataPelajaran, undefined, { numeric: true });
      } else if (sortField === 'guruNama') {
        cmp = a.guruNama.localeCompare(b.guruNama, undefined, { numeric: true });
      } else if (sortField === 'kelasNama') {
        cmp = a.kelasNama.localeCompare(b.kelasNama, undefined, { numeric: true });
      } else if (sortField === 'jamMulai') {
        cmp = (a.jamMulai || '').localeCompare(b.jamMulai || '');
      } else if (sortField === 'shift') {
        cmp = getScheduleShift(a).localeCompare(getScheduleShift(b));
      }

      return sortDirection === 'asc' ? cmp : -cmp;
    });
  }, [filteredJadwal, sortField, sortDirection]);

  const validPageSize = Number.isFinite(pageSize) && pageSize > 0 ? pageSize : 10;
  const validCurrentPage = Number.isFinite(currentPage) && currentPage > 0 ? currentPage : 1;
  const totalPages = Math.ceil(sortedJadwal.length / validPageSize) || 1;
  const startIdx = (validCurrentPage - 1) * validPageSize;
  const pagedJadwal = sortedJadwal.slice(startIdx, startIdx + validPageSize);

  const handleSort = (field: 'mataPelajaran' | 'guruNama' | 'kelasNama' | 'hari' | 'jamMulai' | 'shift') => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Delete Plotting Jadwal
  const handleDeleteJadwal = (item: JadwalMengajarGuru) => {
    if (readOnly) return;
    onConfirmModal(
      'Hapus Plotting Mapel',
      `Apakah Anda yakin ingin menghapus jadwal mata pelajaran "${item.mataPelajaran}" untuk kelas ${item.kelasNama} (${item.guruNama} - Hari ${item.hari})?`,
      'danger',
      () => {
        const updatedJadwal = (appData.jadwalMengajar || []).filter((j) => j.id !== item.id);
        const updatedAppData = addAuditLog(
          { ...appData, jadwalMengajar: updatedJadwal },
          'Hapus Jadwal Mapel',
          `Menghapus plotting mapel ${item.mataPelajaran} (${item.kelasNama} - ${item.guruNama})`
        );
        onUpdateAppData(updatedAppData);
        onShowToast(`Jadwal ${item.mataPelajaran} untuk kelas ${item.kelasNama} berhasil dihapus.`, 'success');
      }
    );
  };

  // Delete All Plotting Jadwal
  const handleDeleteAllJadwal = () => {
    if (readOnly || (appData.jadwalMengajar || []).length === 0) return;
    onConfirmModal(
      'Hapus SEMUA Plotting Jadwal',
      `PERINGATAN: Apakah Anda yakin ingin menghapus SEMUA plotting jadwal mengajar (${(appData.jadwalMengajar || []).length} jadwal)? Tindakan ini akan mengosongkan seluruh jadwal mata pelajaran guru per kelas dan tidak dapat dibatalkan.`,
      'danger',
      () => {
        const updatedAppData = addAuditLog(
          { ...appData, jadwalMengajar: [] },
          'Hapus Semua Jadwal Mapel',
          `Menghapus seluruh plotting jadwal mengajar (${(appData.jadwalMengajar || []).length} jadwal).`
        );
        onUpdateAppData(updatedAppData);
        onShowToast('Semua data plotting jadwal mengajar berhasil dihapus.', 'success');
      }
    );
  };

  // Open Form Modal (Add / Edit Plotting)
  const handleOpenJadwalModal = (jadwalToEdit?: JadwalMengajarGuru) => {
    if (readOnly) return;

    let initialGuruUsername = jadwalToEdit?.guruUsername || (guruList[0]?.username || '');
    let initialMataPelajaran = jadwalToEdit?.mataPelajaran || (mapelList[0]?.nama || '');
    let initialKodeMapel = jadwalToEdit?.kodeMapel || (mapelList[0]?.kode || '');
    let initialKelasId = jadwalToEdit?.kelasId || (kelasList[0]?.id || '');
    let initialHari = jadwalToEdit?.hari || 'Senin';
    let initialShift = jadwalToEdit?.shift || (parseInt((jadwalToEdit?.jamMulai || '07:30').split(':')[0], 10) >= 12 ? 'Siang' : 'Pagi');
    let initialJamMulai = jadwalToEdit?.jamMulai || '07:30';
    let initialJamSelesai = jadwalToEdit?.jamSelesai || '09:30';
    let initialJamKe = jadwalToEdit?.jamKe || '';
    let initialCatatan = jadwalToEdit?.catatan || '';

    const FormModalContent: React.FC = () => {
      const [guruUsername, setGuruUsername] = useState(initialGuruUsername);
      const [mataPelajaran, setMataPelajaran] = useState(initialMataPelajaran);
      const [kodeMapel, setKodeMapel] = useState(initialKodeMapel);
      const [kelasId, setKelasId] = useState(initialKelasId);
      const [hari, setHari] = useState(initialHari);
      const [shift, setShift] = useState(initialShift);
      const [jamMulai, setJamMulai] = useState(initialJamMulai);
      const [jamSelesai, setJamSelesai] = useState(initialJamSelesai);
      const [jamKe, setJamKe] = useState(initialJamKe);
      const [catatan, setCatatan] = useState(initialCatatan);
      const [err, setErr] = useState('');

      const handleMapelSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const val = e.target.value;
        setMataPelajaran(val);
        const matched = mapelList.find((m) => m.nama === val);
        if (matched) {
          setKodeMapel(matched.kode);
        }
      };

      const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        setErr('');

        if (!mataPelajaran.trim()) {
          setErr('Nama Mata Pelajaran tidak boleh kosong.');
          return;
        }
        if (!guruUsername) {
          setErr('Pilih Guru Pengampu.');
          return;
        }
        if (!kelasId) {
          setErr('Pilih Kelas Ajar.');
          return;
        }

        const selectedGuru = guruList.find((g) => g.username === guruUsername);
        const selectedKelas = kelasList.find((k) => k.id === kelasId);

        const guruNama = selectedGuru ? selectedGuru.nama : guruUsername;
        const guruNip = selectedGuru?.nip || '';
        const kelasNama = selectedKelas ? selectedKelas.nama : kelasId;

        const newId = jadwalToEdit ? jadwalToEdit.id : `JADWAL_${Date.now()}`;

        const newJadwalItem: JadwalMengajarGuru = {
          id: newId,
          guruId: selectedGuru?.id,
          guruUsername: guruUsername,
          guruNama: guruNama,
          guruNip: guruNip,
          mataPelajaran: mataPelajaran.trim(),
          kodeMapel: kodeMapel.trim() || undefined,
          kelasId: kelasId,
          kelasNama: kelasNama,
          hari: hari,
          shift: shift,
          jamMulai: jamMulai.trim(),
          jamSelesai: jamSelesai.trim(),
          jamKe: jamKe.trim(),
          catatan: catatan.trim(),
        };

        const currentList = appData.jadwalMengajar || [];
        let updatedList: JadwalMengajarGuru[];

        if (jadwalToEdit) {
          updatedList = currentList.map((j) => (j.id === jadwalToEdit.id ? newJadwalItem : j));
        } else {
          updatedList = [newJadwalItem, ...currentList];
        }

        const updatedAppData = addAuditLog(
          { ...appData, jadwalMengajar: updatedList },
          jadwalToEdit ? 'Edit Jadwal Mapel' : 'Tambah Plotting Mapel',
          `${jadwalToEdit ? 'Mengubah' : 'Menambah'} plotting mapel ${mataPelajaran.trim()} (${kelasNama} - ${guruNama})`
        );

        onUpdateAppData(updatedAppData);
        onCloseModal();
        onShowToast(
          jadwalToEdit
            ? `Jadwal ${mataPelajaran.trim()} untuk ${kelasNama} berhasil diperbarui!`
            : `Plotting mapel ${mataPelajaran.trim()} untuk ${kelasNama} berhasil disimpan!`,
          'success'
        );
      };

      return (
        <form onSubmit={handleSave} className="space-y-4 text-slate-800 dark:text-slate-100">
          {err && (
            <div className="p-3 text-xs rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 font-semibold flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{err}</span>
            </div>
          )}

          {/* Guru Pengampu */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-blue-600" />
              <span>Guru Pengampu</span> <span className="text-rose-500">*</span>
            </label>
            <select
              value={guruUsername}
              onChange={(e) => setGuruUsername(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
              required
            >
              <option value="">-- Pilih Guru Pengampu --</option>
              {guruList.map((g) => (
                <option key={g.id} value={g.username}>
                  {g.nama} {g.nip ? `(NIP: ${g.nip})` : ''} - [{g.username}]
                </option>
              ))}
            </select>
          </div>

          {/* Mata Pelajaran (Dropdown from Master Mapel Catalog + Manual override) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                <span>Pilih dari Master Katalog Mapel</span> <span className="text-rose-500">*</span>
              </label>
              <select
                value={mataPelajaran}
                onChange={handleMapelSelect}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
                required
              >
                <option value="">-- Pilih Mata Pelajaran --</option>
                {mapelList.map((m) => (
                  <option key={m.id} value={m.nama}>
                    [{m.kode}] {m.nama} {m.tingkat ? `(${m.tingkat})` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Atau Input Manual
              </label>
              <input
                type="text"
                value={mataPelajaran}
                onChange={(e) => setMataPelajaran(e.target.value)}
                placeholder="Nama Mapel custom..."
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
              />
            </div>
          </div>

          {/* Kelas, Hari & Shift */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-purple-600" />
                <span>Kelas Ajar</span> <span className="text-rose-500">*</span>
              </label>
              <select
                value={kelasId}
                onChange={(e) => setKelasId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
                required
              >
                <option value="">-- Pilih Kelas --</option>
                {kelasList.map((k) => (
                  <option key={k.id} value={k.id}>
                    {k.nama}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-600" />
                <span>Hari Mengajar</span> <span className="text-rose-500">*</span>
              </label>
              <select
                value={hari}
                onChange={(e) => setHari(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
                required
              >
                {HARI_LIST.map((h) => (
                  <option key={h} value={h}>
                    Hari {h}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Sun className="w-3.5 h-3.5 text-amber-500" />
                <span>Shift</span> <span className="text-rose-500">*</span>
              </label>
              <select
                value={shift}
                onChange={(e) => setShift(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition font-medium"
                required
              >
                <option value="Pagi">☀️ Shift Pagi</option>
                <option value="Siang">🌅 Shift Siang</option>
                <option value="Normal">⏱️ Shift Normal</option>
              </select>
            </div>
          </div>

          {/* Jam Pelajaran */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">
            <div className="text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Alokasi Jam Pelajaran</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Jam Mulai
                </label>
                <input
                  type="text"
                  value={jamMulai}
                  onChange={(e) => setJamMulai(e.target.value)}
                  placeholder="07:30"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Jam Selesai
                </label>
                <input
                  type="text"
                  value={jamSelesai}
                  onChange={(e) => setJamSelesai(e.target.value)}
                  placeholder="09:30"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  Jam Ke (Opsional)
                </label>
                <input
                  type="text"
                  value={jamKe}
                  onChange={(e) => setJamKe(e.target.value)}
                  placeholder="misal: 1 - 3"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-center"
                />
              </div>
            </div>
          </div>

          {/* Catatan */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Catatan / Keterangan (Opsional)
            </label>
            <input
              type="text"
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              placeholder="misal: Materi Praktikum / Teori / Pembahasan Modul"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
            />
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onCloseModal}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{jadwalToEdit ? 'Simpan Perubahan' : 'Simpan Plotting Mapel'}</span>
            </button>
          </div>
        </form>
      );
    };

    onOpenModal(
      jadwalToEdit ? `Edit Plotting Mapel: ${jadwalToEdit.mataPelajaran}` : 'Tambah Plotting Mata Pelajaran & Jadwal',
      <FormModalContent />
    );
  };

  // Export Plotting Jadwal to Excel
  const handleExportJadwalExcel = () => {
    const dataToExport = sortedJadwal.map((j, idx) => ({
      NO: idx + 1,
      NIP_GURU: j.guruNip || '-',
      NAMA_GURU: j.guruNama,
      USERNAME_GURU: j.guruUsername,
      MATA_PELAJARAN: j.mataPelajaran,
      KODE_MAPEL: j.kodeMapel || '-',
      KELAS: j.kelasNama,
      HARI: j.hari,
      SHIFT: getScheduleShift(j),
      JAM_MULAI: j.jamMulai || '-',
      JAM_SELESAI: j.jamSelesai || '-',
      JAM_KE: j.jamKe || '-',
      CATATAN: j.catatan || '-',
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    ws['!cols'] = [
      { wch: 5 },  // NO
      { wch: 22 }, // NIP_GURU
      { wch: 30 }, // NAMA_GURU
      { wch: 18 }, // USERNAME_GURU
      { wch: 32 }, // MATA_PELAJARAN
      { wch: 15 }, // KODE_MAPEL
      { wch: 16 }, // KELAS
      { wch: 12 }, // HARI
      { wch: 12 }, // SHIFT
      { wch: 12 }, // JAM_MULAI
      { wch: 12 }, // JAM_SELESAI
      { wch: 12 }, // JAM_KE
      { wch: 30 }, // CATATAN
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Jadwal Mata Pelajaran');
    XLSX.writeFile(wb, `Master_Plotting_Mata_Pelajaran_${new Date().toISOString().slice(0, 10)}.xlsx`);
    onShowToast('Data Plotting Mata Pelajaran berhasil diexport ke Excel!', 'success');
  };

  // Download Template Plotting Jadwal
  const handleDownloadJadwalTemplate = () => {
    const templateData = [
      {
        NIP_ATAU_USERNAME_GURU: '198501012010011001',
        NAMA_GURU: 'Drs. Ahmad Fauzi, M.Pd.',
        MATA_PELAJARAN: 'Matematika Wajib',
        KELAS: 'XII RPL 1',
        HARI: 'Senin',
        SHIFT: 'Pagi',
        JAM_MULAI: '07:30',
        JAM_SELESAI: '09:30',
        JAM_KE: '1 - 3',
        CATATAN: 'Materi Matriks & Aljabar',
      },
      {
        NIP_ATAU_USERNAME_GURU: '198203032008011003',
        NAMA_GURU: 'Budi Santoso, S.T.',
        MATA_PELAJARAN: 'Pemrograman Web & Perangkat Bergerak',
        KELAS: 'XII RPL 1',
        HARI: 'Selasa',
        SHIFT: 'Siang',
        JAM_MULAI: '12:30',
        JAM_SELESAI: '15:30',
        JAM_KE: '5 - 8',
        CATATAN: 'Praktikum REST API & Full-Stack Web',
      },
    ];

    const ws = XLSX.utils.json_to_sheet(templateData);
    ws['!cols'] = [
      { wch: 25 },
      { wch: 30 },
      { wch: 35 },
      { wch: 16 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 12 },
      { wch: 35 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template Jadwal Mapel');
    XLSX.writeFile(wb, 'Template_Import_Plotting_Mata_Pelajaran_Jadwal.xlsx');
    onShowToast('Template Excel Jadwal Mata Pelajaran berhasil diunduh!', 'info');
  };

  // Import Plotting Jadwal File
  const handleImportJadwalExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json<any>(ws);

        if (!data || data.length === 0) {
          onShowToast('File Excel kosong atau format tidak sesuai.', 'error');
          return;
        }

        let addedCount = 0;
        let updatedCount = 0;
        const currentJadwal = [...(appData.jadwalMengajar || [])];

        data.forEach((row, index) => {
          const rawMapel = String(
            row.MATA_PELAJARAN || row.MAPEL || row.Mapel || row.mata_pelajaran || ''
          ).trim();
          if (!rawMapel) return;

          const rawGuruKey = String(
            row.NIP_ATAU_USERNAME_GURU || row.NIP || row.USERNAME || row.GURU || row.NAMA_GURU || row.Nama_Guru || ''
          ).trim();

          let matchedGuru = guruList.find(
            (g) =>
              (g.nip && g.nip.toLowerCase() === rawGuruKey.toLowerCase()) ||
              g.username.toLowerCase() === rawGuruKey.toLowerCase() ||
              g.nama.toLowerCase() === rawGuruKey.toLowerCase() ||
              g.nama.toLowerCase().includes(rawGuruKey.toLowerCase())
          );

          const rawKelasStr = String(
            row.KELAS || row.Kelas || row.kelas || row.KELAS_AJAR || ''
          ).trim();

          let matchedKelas = kelasList.find(
            (k) =>
              k.nama.toLowerCase().replace(/\s+/g, '') === rawKelasStr.toLowerCase().replace(/\s+/g, '') ||
              k.id.toLowerCase() === rawKelasStr.toLowerCase()
          );

          const rawHariStr = String(row.HARI || row.Hari || row.hari || 'Senin').trim();
          const matchedHari = HARI_LIST.find(
            (h) => h.toLowerCase() === rawHariStr.toLowerCase()
          ) || 'Senin';

          const rawJamMulai = String(row.JAM_MULAI || row.Jam_Mulai || row.jam_mulai || '07:30').trim();
          const rawJamSelesai = String(row.JAM_SELESAI || row.Jam_Selesai || row.jam_selesai || '09:30').trim();
          const rawShift = String(row.SHIFT || row.Shift || row.shift || (parseInt((rawJamMulai || '').split(':')[0], 10) >= 12 ? 'Siang' : 'Pagi')).trim();
          const rawJamKe = String(row.JAM_KE || row.Jam_Ke || row.jam_ke || '').trim();
          const rawCatatan = String(row.CATATAN || row.Catatan || row.catatan || '').trim();

          const guruUsername = matchedGuru ? matchedGuru.username : (rawGuruKey || 'guru_umum');
          const guruNama = matchedGuru ? matchedGuru.nama : (String(row.NAMA_GURU || row.Nama_Guru || rawGuruKey) || 'Guru Mata Pelajaran');
          const guruNip = matchedGuru?.nip || '';
          const kelasId = matchedKelas ? matchedKelas.id : (rawKelasStr || 'KELAS_UMUM');
          const kelasNama = matchedKelas ? matchedKelas.nama : (rawKelasStr || 'Semua Kelas');

          const existingIdx = currentJadwal.findIndex(
            (j) =>
              j.guruUsername.toLowerCase() === guruUsername.toLowerCase() &&
              j.mataPelajaran.toLowerCase() === rawMapel.toLowerCase() &&
              j.kelasNama.toLowerCase().replace(/\s+/g, '') === kelasNama.toLowerCase().replace(/\s+/g, '') &&
              j.hari.toLowerCase() === matchedHari.toLowerCase()
          );

          if (existingIdx >= 0) {
            currentJadwal[existingIdx] = {
              ...currentJadwal[existingIdx],
              guruNama: guruNama,
              guruNip: guruNip,
              shift: rawShift,
              jamMulai: rawJamMulai,
              jamSelesai: rawJamSelesai,
              jamKe: rawJamKe,
              catatan: rawCatatan,
            };
            updatedCount++;
          } else {
            currentJadwal.push({
              id: `JADWAL_IMP_${Date.now()}_${index}`,
              guruId: matchedGuru?.id,
              guruUsername: guruUsername,
              guruNama: guruNama,
              guruNip: guruNip,
              mataPelajaran: rawMapel,
              kelasId: kelasId,
              kelasNama: kelasNama,
              hari: matchedHari,
              shift: rawShift,
              jamMulai: rawJamMulai,
              jamSelesai: rawJamSelesai,
              jamKe: rawJamKe,
              catatan: rawCatatan,
            });
            addedCount++;
          }
        });

        const updatedAppData = addAuditLog(
          { ...appData, jadwalMengajar: currentJadwal },
          'Import Jadwal Mapel',
          `Import Excel plotting mapel: ${addedCount} baru, ${updatedCount} diperbarui.`
        );
        onUpdateAppData(updatedAppData);

        onShowToast(
          `Import Selesai! ${addedCount} jadwal baru ditambahkan, ${updatedCount} diperbarui.`,
          'success'
        );
      } catch (err: any) {
        onShowToast(`Gagal meng-import file Excel: ${err.message}`, 'error');
      } finally {
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <PageHeader
        title="Master Mata Pelajaran & Jadwal Mengajar"
        description="Pusat kelola katalog kurikulum mata pelajaran baku sekolah serta plotting jadwal mengajar guru per kelas dan hari."
        icon={BookOpen}
        actions={
          !readOnly ? (
            <div className="flex items-center gap-2">
              {activeTab === 'katalog' ? (
                <button
                  type="button"
                  onClick={() => handleOpenMasterMapelModal()}
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Master Mapel</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleOpenJadwalModal()}
                  className="px-4 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Plotting Jadwal</span>
                </button>
              )}
            </div>
          ) : undefined
        }
      />

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        <button
          type="button"
          onClick={() => setActiveTab('katalog')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'katalog'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Katalog Master Mapel</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
              activeTab === 'katalog'
                ? 'bg-white/20 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {mapelList.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('plotting')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'plotting'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Plotting & Jadwal Guru</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
              activeTab === 'plotting'
                ? 'bg-white/20 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {jadwalList.length}
          </span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1 CONTENT: KATALOG MASTER MATA PELAJARAN
          ========================================================================= */}
      {activeTab === 'katalog' && (
        <div className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">{mapelList.length}</div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Total Mata Pelajaran</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                  {mapelList.filter((m) => m.kategori?.includes('Kelompok C') || m.kategori?.includes('Kejuruan')).length}
                </div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Mapel Produktif / Kejuruan</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                  {mapelList.filter((m) => m.kategori?.includes('Kelompok A') || m.kategori?.includes('Nasional')).length}
                </div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Muatan Nasional (Kelompok A)</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                  {mapelList.reduce((acc, m) => acc + (m.alokasiJp || 0), 0)} JP
                </div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Total Beban Jam (JP)</div>
              </div>
            </div>
          </div>

          {/* Filter & Toolbar */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* Search */}
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={mapelSearch}
                  onChange={(e) => {
                    setMapelSearch(e.target.value);
                    setMapelPage(1);
                  }}
                  placeholder="Cari KODE, NAMA MAPEL, JURUSAN, SILABUS..."
                  className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
                />
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={mapelFilterKategori}
                  onChange={(e) => {
                    setMapelFilterKategori(e.target.value);
                    setMapelPage(1);
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition"
                >
                  <option value="semua">Semua Kategori</option>
                  {MAPEL_KATEGORI_OPTIONS.map((k) => (
                    <option key={k} value={k}>
                      {k}
                    </option>
                  ))}
                </select>

                <select
                  value={mapelFilterTingkat}
                  onChange={(e) => {
                    setMapelFilterTingkat(e.target.value);
                    setMapelPage(1);
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition"
                >
                  <option value="semua">Semua Tingkat</option>
                  {TINGKAT_OPTIONS.map((t) => (
                    <option key={t} value={t}>
                      {t === 'Semua Tingkat' ? 'Semua Tingkat' : `Kelas ${t}`}
                    </option>
                  ))}
                </select>

                {/* View Mode Switcher for Master Mapel */}
                <div className="flex items-center rounded-xl bg-slate-100 dark:bg-slate-800 p-0.5 border border-slate-200 dark:border-slate-700 shrink-0">
                  <button
                    type="button"
                    onClick={() => setMapelViewMode('list')}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                      mapelViewMode === 'list'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                    title="Tampilan Tabel / List"
                  >
                    <List className="w-3.5 h-3.5" />
                    <span>List</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMapelViewMode('grid')}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                      mapelViewMode === 'grid'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                    title="Tampilan Kartu / Grid"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span>Grid</span>
                  </button>
                </div>

                {/* Import / Export Master Mapel */}
                <input
                  type="file"
                  ref={mapelCatalogFileInputRef}
                  onChange={handleImportMapelCatalog}
                  accept=".xlsx, .xls, .csv"
                  className="hidden"
                />

                {!readOnly && (
                  <>
                    <button
                      type="button"
                      onClick={() => mapelCatalogFileInputRef.current?.click()}
                      className="px-3 py-2 text-xs font-bold rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                      title="Import Katalog Master dari Excel"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Import Excel</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleDownloadMapelCatalogTemplate}
                      className="px-3 py-2 text-xs font-bold rounded-xl bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                      title="Unduh Template Master Mapel"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Template</span>
                    </button>
                  </>
                )}

                <button
                  type="button"
                  onClick={handleExportMapelCatalog}
                  className="px-3 py-2 text-xs font-bold rounded-xl bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  title="Export Katalog Master ke Excel"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export</span>
                </button>

                {!readOnly && mapelList.length > 0 && (
                  <button
                    type="button"
                    onClick={handleDeleteAllMasterMapel}
                    className="px-3 py-2 text-xs font-bold rounded-xl bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800 hover:bg-rose-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="Hapus Semua Master Mata Pelajaran"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Semua</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Master Mapel Content: List Table or Grid Cards */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
            {mapelViewMode === 'grid' ? (
              /* Grid View: Responsive Cards */
              <div className="p-4 sm:p-6">
                {pagedMapel.length === 0 ? (
                  <div className="py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <BookOpen className="w-8 h-8 opacity-40" />
                      <p className="font-bold">Tidak ada mata pelajaran ditemukan dalam katalog master.</p>
                      <p className="text-[11px] text-slate-500">
                        Gunakan tombol "+ Tambah Master Mapel" atau "Import Excel" untuk menambahkan kurikulum baru.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {pagedMapel.map((item, index) => {
                      const globalIdx = mapelStartIdx + index + 1;
                      return (
                        <div
                          key={item.id}
                          className="p-4 bg-white dark:bg-slate-800/90 hover:shadow-md border border-slate-200/80 dark:border-slate-700/80 rounded-2xl flex flex-col justify-between shadow-xs transition duration-150"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2 mb-2.5">
                              <div className="flex items-center gap-2 min-w-0">
                                <span className="inline-flex items-center justify-center w-7 h-7 rounded-xl bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 font-extrabold text-xs shrink-0">
                                  #{globalIdx}
                                </span>
                                <span className="px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                                  {item.kode}
                                </span>
                              </div>
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800 shrink-0">
                                {item.tingkat || 'Semua'}
                              </span>
                            </div>

                            <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm leading-tight mb-1" title={item.nama}>
                              {item.nama}
                            </h4>

                            {item.jurusanNama && (
                              <div className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold mb-2">
                                Jurusan: {item.jurusanNama}
                              </div>
                            )}

                            <div className="mb-2.5">
                              <span
                                className={`inline-flex items-center px-2 py-0.5 rounded-lg text-[10px] font-bold border ${
                                  item.kategori?.includes('Kelompok C') || item.kategori?.includes('Kejuruan')
                                    ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border-purple-200 dark:border-purple-800'
                                    : item.kategori?.includes('Kelompok A')
                                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                                    : item.kategori?.includes('Kelompok B')
                                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200'
                                }`}
                              >
                                {item.kategori || 'Umum'}
                              </span>
                            </div>

                            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-1.5 text-[11px] mb-2 border border-slate-100 dark:border-slate-700/50">
                              <div className="flex items-center justify-between">
                                <span className="text-slate-500 dark:text-slate-400">Beban Waktu:</span>
                                <span className="font-bold text-slate-800 dark:text-slate-200">{item.alokasiJp ? `${item.alokasiJp} JP` : '-'}</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-slate-500 dark:text-slate-400">KKM Minimum:</span>
                                <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400">{item.kkm || 75}</span>
                              </div>
                            </div>

                            {item.deskripsi && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 italic mb-2">
                                {item.deskripsi}
                              </p>
                            )}
                          </div>

                          {!readOnly && (
                            <div className="pt-2.5 mt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleOpenMasterMapelModal(item)}
                                className="px-2.5 py-1 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                title="Edit Master Mapel"
                              >
                                <Edit className="w-3.5 h-3.5" />
                                <span>Edit</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleDeleteMasterMapel(item)}
                                className="px-2.5 py-1 rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                                title="Hapus Master Mapel"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Hapus</span>
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              /* List View: Data Table */
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 text-[11px] uppercase tracking-wider font-extrabold border-b border-slate-200 dark:border-slate-800">
                      <th className="py-3 px-3 w-12 text-center">No</th>
                      <th
                        className="py-3 px-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition w-32"
                        onClick={() => handleMapelSort('kode')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Kode Mapel</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th
                        className="py-3 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition"
                        onClick={() => handleMapelSort('nama')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Nama Mata Pelajaran</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th
                        className="py-3 px-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition"
                        onClick={() => handleMapelSort('kategori')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Kategori / Kelompok</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th className="py-3 px-3 text-center">Tingkat</th>
                      <th
                        className="py-3 px-3 text-center cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition w-24"
                        onClick={() => handleMapelSort('alokasiJp')}
                      >
                        <div className="flex items-center justify-center gap-1.5">
                          <span>Beban (JP)</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th className="py-3 px-3 text-center w-20">KKM</th>
                      <th className="py-3 px-3">Deskripsi / Silabus</th>
                      {!readOnly && <th className="py-3 px-4 text-center w-24">Aksi</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-200">
                    {pagedMapel.length === 0 ? (
                      <tr>
                        <td colSpan={readOnly ? 8 : 9} className="py-12 text-center text-slate-400">
                          <div className="flex flex-col items-center justify-center space-y-2">
                            <BookOpen className="w-8 h-8 opacity-40" />
                            <p className="font-bold">Tidak ada mata pelajaran ditemukan dalam katalog master.</p>
                            <p className="text-[11px] text-slate-500">
                              Gunakan tombol "+ Tambah Master Mapel" atau "Import Excel" untuk menambahkan kurikulum baru.
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      pagedMapel.map((item, index) => {
                        const globalIdx = mapelStartIdx + index + 1;
                        return (
                          <tr
                            key={item.id}
                            className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                          >
                            <td className="py-3 px-3 text-center text-slate-400 font-mono text-[11px]">
                              {globalIdx}
                            </td>

                            <td className="py-3 px-3">
                              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                                {item.kode}
                              </span>
                            </td>

                            <td className="py-3 px-4">
                              <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                                <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
                                <span>{item.nama}</span>
                              </div>
                              {item.jurusanNama && (
                                <div className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold mt-0.5">
                                  Jurusan: {item.jurusanNama}
                                </div>
                              )}
                            </td>

                            <td className="py-3 px-3">
                              <span
                                className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-[10px] font-bold border ${
                                  item.kategori?.includes('Kelompok C') || item.kategori?.includes('Kejuruan')
                                    ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border-purple-200 dark:border-purple-800'
                                    : item.kategori?.includes('Kelompok A')
                                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                                    : item.kategori?.includes('Kelompok B')
                                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200'
                                }`}
                              >
                                {item.kategori || 'Umum'}
                              </span>
                            </td>

                            <td className="py-3 px-3 text-center">
                              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                                {item.tingkat || 'Semua'}
                              </span>
                            </td>

                            <td className="py-3 px-3 text-center font-bold text-slate-800 dark:text-slate-200">
                              {item.alokasiJp ? `${item.alokasiJp} JP` : '-'}
                            </td>

                            <td className="py-3 px-3 text-center font-semibold text-slate-700 dark:text-slate-300 font-mono">
                              {item.kkm || 75}
                            </td>

                            <td className="py-3 px-3">
                              <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                                {item.deskripsi || '-'}
                              </span>
                            </td>

                            {!readOnly && (
                              <td className="py-3 px-4 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenMasterMapelModal(item)}
                                    className="p-1.5 rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition cursor-pointer"
                                    title="Edit Master Mapel"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => handleDeleteMasterMapel(item)}
                                    className="p-1.5 rounded-lg bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/60 transition cursor-pointer"
                                    title="Hapus Master Mapel"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            )}
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination for Master Mapel */}
            {sortedMapel.length > 0 && (
              <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                <Pagination
                  currentPage={mapelPage}
                  totalPages={mapelTotalPages}
                  onPageChange={setMapelPage}
                  pageSize={mapelPageSize}
                  onPageSizeChange={(newSize) => {
                    setMapelPageSize(newSize);
                    setMapelPage(1);
                  }}
                  totalItems={sortedMapel.length}
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2 CONTENT: PLOTTING JADWAL & ALOKASI MENGAJAR GURU
          ========================================================================= */}
      {activeTab === 'plotting' && (
        <div className="space-y-4">
          {/* Summary Statistics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">{jadwalList.length}</div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Total Plotting Sesi</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                  {new Set(jadwalList.map((j) => j.mataPelajaran.trim().toLowerCase())).size}
                </div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Mata Pelajaran Terjadwal</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                  {new Set(jadwalList.map((j) => (j.guruUsername || j.guruNama).trim().toLowerCase())).size}
                </div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Guru Terjadwal</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                  {new Set(jadwalList.map((j) => (j.kelasId || j.kelasNama).trim().toLowerCase())).size}
                </div>
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Kelas Terjadwal</div>
              </div>
            </div>
          </div>

          {/* Toolbar & Filters */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
              {/* Search Box */}
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                  placeholder="Cari MAPEL, GURU, KELAS, RUANGAN..."
                  className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-blue-500 outline-none transition"
                />
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Hari Filter */}
                <select
                  value={filterHari}
                  onChange={(e) => {
                    setFilterHari(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition"
                >
                  <option value="semua">Semua Hari</option>
                  {HARI_LIST.map((h) => (
                    <option key={h} value={h}>
                      Hari {h}
                    </option>
                  ))}
                </select>

                {/* Kelas Filter */}
                <select
                  value={filterKelas}
                  onChange={(e) => {
                    setFilterKelas(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition"
                >
                  <option value="semua">Semua Kelas</option>
                  {kelasList.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.nama}
                    </option>
                  ))}
                </select>

                {/* Guru Filter */}
                <select
                  value={filterGuru}
                  onChange={(e) => {
                    setFilterGuru(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition"
                >
                  <option value="semua">Semua Guru</option>
                  {guruList.map((g) => (
                    <option key={g.id} value={g.username}>
                      {g.nama}
                    </option>
                  ))}
                </select>

                {/* Shift Filter */}
                <select
                  value={filterShift}
                  onChange={(e) => {
                    setFilterShift(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none transition"
                >
                  <option value="semua">Semua Shift</option>
                  <option value="Pagi">☀️ Shift Pagi</option>
                  <option value="Siang">🌅 Shift Siang</option>
                  <option value="Normal">⏱️ Shift Normal</option>
                </select>

                {/* View Mode Toggle */}
                <div className="flex items-center rounded-xl bg-slate-100 dark:bg-slate-800 p-0.5 border border-slate-200 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() => setViewMode('table')}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                      viewMode === 'table'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                    title="Tampilan Tabel Lengkap"
                  >
                    <List className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Tabel</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setViewMode('byDay')}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                      viewMode === 'byDay'
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                    title="Tampilan Dikelompokkan Per Hari"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Per Hari</span>
                  </button>
                </div>

                {/* Excel Actions */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImportJadwalExcel}
                  accept=".xlsx, .xls, .csv"
                  className="hidden"
                />

                {!readOnly && (
                  <>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-2 text-xs font-bold rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                      title="Import Plotting Mapel dari Excel"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Import Excel</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleDownloadJadwalTemplate}
                      className="px-3 py-2 text-xs font-bold rounded-xl bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                      title="Unduh Format Template Excel"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Template</span>
                    </button>
                  </>
                )}

                <button
                  type="button"
                  onClick={handleExportJadwalExcel}
                  className="px-3 py-2 text-xs font-bold rounded-xl bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  title="Export Plotting Mapel ke Excel"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export</span>
                </button>

                {!readOnly && (appData.jadwalMengajar || []).length > 0 && (
                  <button
                    type="button"
                    onClick={handleDeleteAllJadwal}
                    className="px-3 py-2 text-xs font-bold rounded-xl bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800 hover:bg-rose-100 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                    title="Hapus Semua Plotting Jadwal Mengajar"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Semua</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Plotting Content: Table or By Day */}
          {viewMode === 'table' ? (
            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 text-[11px] uppercase tracking-wider font-extrabold border-b border-slate-200 dark:border-slate-800">
                      <th className="py-3 px-3 w-12 text-center">No</th>
                      <th
                        className="py-3 px-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition w-28"
                        onClick={() => handleSort('hari')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Hari & Jam</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th
                        className="py-3 px-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition w-24"
                        onClick={() => handleSort('shift')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Shift</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th
                        className="py-3 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition"
                        onClick={() => handleSort('mataPelajaran')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Mata Pelajaran</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th
                        className="py-3 px-3 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition"
                        onClick={() => handleSort('kelasNama')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Kelas Ajar</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th
                        className="py-3 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition"
                        onClick={() => handleSort('guruNama')}
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Guru Pengampu</span>
                          <ArrowUpDown className="w-3 h-3 text-slate-400" />
                        </div>
                      </th>
                      <th className="py-3 px-3">Catatan</th>
                      {!readOnly && <th className="py-3 px-4 text-center w-28">Aksi</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-200">
                    {pagedJadwal.length === 0 ? (
                      <tr>
                        <td colSpan={readOnly ? 7 : 8} className="py-12 text-center text-slate-400">
                          <div className="flex flex-col items-center justify-center space-y-2">
                            <BookOpen className="w-8 h-8 opacity-40" />
                            <p className="font-bold">Tidak ada data jadwal mata pelajaran ditemukan.</p>
                            <p className="text-[11px] text-slate-500">
                              Gunakan tombol "+ Tambah Plotting Jadwal" atau "Import Excel" untuk menambahkan jadwal baru.
                            </p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      pagedJadwal.map((item, index) => {
                        const globalIdx = startIdx + index + 1;
                        const itemShift = getScheduleShift(item);
                        const isSiang = itemShift.toLowerCase().includes('siang');
                        return (
                          <tr
                            key={item.id}
                            className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                          >
                            <td className="py-3 px-3 text-center text-slate-400 font-mono text-[11px]">
                              {globalIdx}
                            </td>

                            <td className="py-3 px-3">
                              <div className="space-y-1">
                                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                                  {item.hari}
                                </span>
                                <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1 font-mono">
                                  <Clock className="w-3 h-3 text-slate-400" />
                                  <span>{item.jamMulai && item.jamSelesai ? `${item.jamMulai} - ${item.jamSelesai}` : (item.jamMulai || '-')}</span>
                                </div>
                                {item.jamKe && (
                                  <div className="text-[10px] text-slate-400">
                                    Jam ke {item.jamKe}
                                  </div>
                                )}
                              </div>
                            </td>

                            <td className="py-3 px-3">
                              <span
                                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border ${
                                  isSiang
                                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                                    : 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300 border-sky-200 dark:border-sky-800'
                                }`}
                              >
                                {isSiang ? <Sunset className="w-3 h-3" /> : <Sun className="w-3 h-3" />}
                                <span>{itemShift}</span>
                              </span>
                            </td>

                            <td className="py-3 px-4">
                              <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                                <BookOpen className="w-4 h-4 text-emerald-600 shrink-0" />
                                <span>{item.mataPelajaran}</span>
                              </div>
                              {item.kodeMapel && (
                                <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">
                                  Kode: {item.kodeMapel}
                                </span>
                              )}
                            </td>

                            <td className="py-3 px-3">
                              <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                                {item.kelasNama}
                              </span>
                            </td>

                            <td className="py-3 px-4">
                              <div className="space-y-0.5">
                                <div className="font-bold text-slate-900 dark:text-slate-100">
                                  {item.guruNama}
                                </div>
                                <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
                                  {item.guruNip && <span>NIP: {item.guruNip}</span>}
                                  <span className="font-mono text-slate-400">@{item.guruUsername}</span>
                                </div>
                              </div>
                            </td>

                            <td className="py-3 px-3">
                              {item.catatan ? (
                                <div className="text-[11px] text-slate-600 dark:text-slate-300 italic max-w-xs">
                                  {item.catatan}
                                </div>
                              ) : (
                                <span className="text-[11px] text-slate-400">-</span>
                              )}
                            </td>

                            {!readOnly && (
                              <td className="py-3 px-4 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenJadwalModal(item)}
                                    className="p-1.5 rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950/50 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition cursor-pointer"
                                    title="Edit Plotting Mapel"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => handleDeleteJadwal(item)}
                                    className="p-1.5 rounded-lg bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/60 transition cursor-pointer"
                                    title="Hapus Plotting Mapel"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            )}
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {sortedJadwal.length > 0 && (
                <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                  <Pagination
                    currentPage={validCurrentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    pageSize={validPageSize}
                    onPageSizeChange={(newSize) => {
                      setPageSize(newSize);
                      setCurrentPage(1);
                    }}
                    totalItems={sortedJadwal.length}
                  />
                </div>
              )}
            </div>
          ) : (
            /* Mode Per Hari (Matrix Cards View) */
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {HARI_LIST.map((hariName) => {
                const daySchedules = sortedJadwal.filter(
                  (j) => j.hari.toLowerCase() === hariName.toLowerCase()
                );

                return (
                  <div
                    key={hariName}
                    className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden flex flex-col"
                  >
                    <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        <span className="font-extrabold text-xs uppercase tracking-wide text-slate-800 dark:text-slate-100">
                          Hari {hariName}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300">
                        {daySchedules.length} Sesi
                      </span>
                    </div>

                    <div className="p-3 divide-y divide-slate-100 dark:divide-slate-800/60 flex-1 space-y-3">
                      {daySchedules.length === 0 ? (
                        <div className="py-8 text-center text-slate-400 text-xs font-medium">
                          Tidak ada jadwal mengajar pada hari {hariName}.
                        </div>
                      ) : (
                        daySchedules.map((item) => (
                          <div key={item.id} className="pt-2 first:pt-0 space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <div className="font-bold text-xs text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                                  <BookOpen className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  <span>{item.mataPelajaran}</span>
                                </div>
                                <div className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5 mt-0.5">
                                  <Users className="w-3 h-3 text-slate-400 shrink-0" />
                                  <span>{item.guruNama}</span>
                                </div>
                              </div>

                              <div className="flex flex-col items-end gap-1 shrink-0">
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                                  {item.kelasNama}
                                </span>
                                <span
                                  className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold border ${
                                    getScheduleShift(item).toLowerCase().includes('siang')
                                      ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                                      : 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300 border-sky-200 dark:border-sky-800'
                                  }`}
                                >
                                  {getScheduleShift(item).toLowerCase().includes('siang') ? (
                                    <Sunset className="w-2.5 h-2.5" />
                                  ) : (
                                    <Sun className="w-2.5 h-2.5" />
                                  )}
                                  <span>{getScheduleShift(item)}</span>
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/40 px-2.5 py-1.5 rounded-lg">
                              <div className="flex items-center gap-1 font-mono">
                                <Clock className="w-3 h-3 text-blue-500" />
                                <span>{item.jamMulai} - {item.jamSelesai}</span>
                                {item.jamKe && <span>(Jam ke {item.jamKe})</span>}
                              </div>
                              {item.catatan && (
                                <span className="italic max-w-[140px] truncate" title={item.catatan}>
                                  {item.catatan}
                                </span>
                              )}
                            </div>

                            {!readOnly && (
                              <div className="flex items-center justify-end gap-1.5 pt-1">
                                <button
                                  type="button"
                                  onClick={() => handleOpenJadwalModal(item)}
                                  className="px-2 py-0.5 rounded text-[10px] font-bold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50 transition cursor-pointer"
                                >
                                  Edit
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteJadwal(item)}
                                  className="px-2 py-0.5 rounded text-[10px] font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition cursor-pointer"
                                >
                                  Hapus
                                </button>
                              </div>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
