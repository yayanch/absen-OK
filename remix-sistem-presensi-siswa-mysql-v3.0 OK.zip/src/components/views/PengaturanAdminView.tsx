import React, { useState } from 'react';
import { UserCog, UserCheck, Save, Trash2, User, Lock, ShieldCheck, Activity, CheckCircle, XCircle } from 'lucide-react';
import { AppData, AdminAccount, UserSession } from '../../types';
import { PageHeader } from '../common/UIComponents';
import { compressBase64Image } from '../../utils/helpers';
import { runAutomatedGoldenDatasetSuite, GoldenDatasetTestResult } from '../../utils/reportEngine';

interface PengaturanAdminViewProps {
  appData: AppData;
  currentUser: UserSession;
  onUpdateAppData: (updated: AppData) => void;
  onUpdateSession: (session: UserSession) => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'warning' | 'info') => void;
}

export const PengaturanAdminView: React.FC<PengaturanAdminViewProps> = ({
  appData,
  currentUser,
  onUpdateAppData,
  onUpdateSession,
  onShowToast,
}) => {
  const [testResults, setTestResults] = useState<GoldenDatasetTestResult[] | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const getInitialState = () => {
    if (currentUser.role === 'admin') {
      const a = appData.admin || { username: 'admin', password: 'admin123', nama: 'Administrator Utama', foto: '' };
      return { nama: a.nama || '', username: a.username || '', password: a.password || '', foto: a.foto || '', jabatan: 'Administrator' };
    } else if (currentUser.role === 'murid') {
      const currentData = currentUser.data as any;
      const found = appData.siswa?.find((s) => s.id === currentData.id || s.nisn === currentData.nisn);
      const s = found || currentData || { nama: '', username: '', password: '', foto: '' };
      return {
        nama: s.nama || '',
        username: s.username || s.nisn || '',
        password: s.password || s.nisn || '',
        foto: s.foto || '',
        jabatan: 'Siswa / Murid',
      };
    } else if (currentUser.role === 'kesiswaan') {
      const currentData = currentUser.data as any;
      const foundInWali = appData.waliKelas?.find((w) => w.id === currentData.id || w.username === currentData.username || w.role === 'kesiswaan');
      const kesiswaanObj = appData.kesiswaan;
      const u = foundInWali || kesiswaanObj || currentData || { nama: '', username: '', password: '', foto: '' };
      return {
        nama: u.nama || 'Tim WKS Kesiswaan & BP BK',
        username: u.username || 'kesiswaan',
        password: u.password || '123',
        foto: u.foto || '',
        jabatan: u.jabatan || 'WKS Kesiswaan / BP BK',
      };
    } else if (currentUser.role === 'user' || currentUser.role === 'guru') {
      const currentData = currentUser.data as any;
      const foundInWali = appData.waliKelas?.find((w) => w.id === currentData.id || w.username === currentData.username || w.role === 'guru' || w.role === 'user');
      const userBiasaObj = appData.userBiasa;
      const u = foundInWali || userBiasaObj || currentData || { nama: '', username: '', password: '', foto: '' };
      return {
        nama: u.nama || 'Guru / Staf Pengajar',
        username: u.username || 'guru',
        password: u.password || '123',
        foto: u.foto || '',
        jabatan: u.jabatan || 'Guru Pengampu',
      };
    } else {
      const currentData = currentUser.data as any;
      const found = appData.waliKelas?.find((w) => w.id === currentData.id || w.username === currentData.username || (w.nip && w.nip === currentData.nip));
      const u = found || currentData || { nama: '', username: '', password: '', foto: '' };
      return {
        nama: u.nama || '',
        username: u.username || u.nip || '',
        password: u.password || '123',
        foto: u.foto || '',
        jabatan: currentUser.role === 'kurikulum' ? 'WKS Kurikulum' : currentUser.role === 'hubin' ? 'WKS Hubin / Humas' : 'Wali Kelas',
      };
    }
  };

  const initial = getInitialState();
  const [nama, setNama] = useState(initial.nama);
  const [jabatan, setJabatan] = useState(initial.jabatan);
  const [username, setUsername] = useState(initial.username);
  const [password, setPassword] = useState(initial.password);
  const [fotoBase64, setFotoBase64] = useState(initial.foto);

  const handleFotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      const raw = evt.target?.result as string;
      const compressed = await compressBase64Image(raw, 350, 0.7);
      setFotoBase64(compressed);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanNama = nama.trim();
    const cleanUsername = username.trim();
    const cleanPassword = password.trim();
    const cleanJabatan = jabatan.trim();

    let nextAppData: AppData = { ...appData };

    if (currentUser.role === 'admin') {
      const newAdmin: AdminAccount = {
        nama: cleanNama || 'Administrator Utama',
        username: cleanUsername || 'admin',
        password: cleanPassword,
        foto: fotoBase64,
      };
      nextAppData.admin = newAdmin;
      onUpdateSession({ role: 'admin', data: newAdmin });
    } else if (currentUser.role === 'kesiswaan') {
      const updatedKesiswaan = {
        ...(appData.kesiswaan || { jabatan: 'WKS Kesiswaan / BP BK' }),
        nama: cleanNama || 'Tim WKS Kesiswaan & BP BK',
        username: cleanUsername || 'kesiswaan',
        password: cleanPassword,
        foto: fotoBase64,
        jabatan: cleanJabatan || 'WKS Kesiswaan / BP BK',
      };
      nextAppData.kesiswaan = updatedKesiswaan;

      let updatedWaliList = [...(appData.waliKelas || [])];
      const currentData = currentUser.data as any;
      const existsIndex = updatedWaliList.findIndex((w) => w.id === currentData.id || w.username === currentData.username || w.role === 'kesiswaan');
      if (existsIndex >= 0) {
        updatedWaliList[existsIndex] = {
          ...updatedWaliList[existsIndex],
          nama: cleanNama || updatedWaliList[existsIndex].nama,
          username: cleanUsername || updatedWaliList[existsIndex].username,
          password: cleanPassword,
          foto: fotoBase64,
          role: 'kesiswaan',
          jabatan: cleanJabatan || 'WKS Kesiswaan / BP BK',
        };
      } else {
        updatedWaliList.push({
          id: currentData.id || 'USER_KESISWAAN',
          nip: currentData.nip || cleanUsername,
          nama: cleanNama || 'Tim WKS Kesiswaan & BP BK',
          username: cleanUsername || 'kesiswaan',
          password: cleanPassword,
          noHp: currentData.noHp || '',
          role: 'kesiswaan',
          foto: fotoBase64,
          jabatan: cleanJabatan || 'WKS Kesiswaan / BP BK',
        });
      }
      nextAppData.waliKelas = updatedWaliList;
      onUpdateSession({ role: 'kesiswaan', data: updatedKesiswaan });
    } else if (currentUser.role === 'user' || currentUser.role === 'guru') {
      const updatedUserBiasa = {
        ...(appData.userBiasa || { jabatan: 'Guru Pengampu' }),
        nama: cleanNama || 'Guru / Staf Pengajar',
        username: cleanUsername || 'guru',
        password: cleanPassword,
        foto: fotoBase64,
        jabatan: cleanJabatan || 'Guru Pengampu',
      };
      nextAppData.userBiasa = updatedUserBiasa;

      let updatedWaliList = [...(appData.waliKelas || [])];
      const currentData = currentUser.data as any;
      const existsIndex = updatedWaliList.findIndex((w) => w.id === currentData.id || w.username === currentData.username || w.role === 'guru' || w.role === 'user');
      if (existsIndex >= 0) {
        updatedWaliList[existsIndex] = {
          ...updatedWaliList[existsIndex],
          nama: cleanNama || updatedWaliList[existsIndex].nama,
          username: cleanUsername || updatedWaliList[existsIndex].username,
          password: cleanPassword,
          foto: fotoBase64,
          role: 'guru',
          jabatan: cleanJabatan || 'Guru Pengampu',
        };
      } else {
        updatedWaliList.push({
          id: currentData.id || 'USER_BIASA',
          nip: currentData.nip || cleanUsername,
          nama: cleanNama || 'Guru / Staf Pengajar',
          username: cleanUsername || 'guru',
          password: cleanPassword,
          noHp: currentData.noHp || '',
          role: 'guru',
          foto: fotoBase64,
          jabatan: cleanJabatan || 'Guru Pengampu',
        });
      }
      nextAppData.waliKelas = updatedWaliList;
      onUpdateSession({ role: 'guru', data: updatedUserBiasa });
    } else if (currentUser.role === 'murid') {
      const currentData = currentUser.data as any;
      const updatedSiswa = (appData.siswa || []).map((s) => {
        if (s.id === currentData.id || s.nisn === currentData.nisn) {
          const newS = {
            ...s,
            nama: cleanNama || s.nama,
            username: cleanUsername || s.username || s.nisn,
            password: cleanPassword ? cleanPassword : (s.password || s.nisn || ''),
            foto: fotoBase64 || s.foto,
          };
          onUpdateSession({ role: 'murid', data: newS });
          return newS;
        }
        return s;
      });
      nextAppData.siswa = updatedSiswa;
    } else {
      // Wali Kelas / Kurikulum / Hubin
      let updatedWaliList = [...(appData.waliKelas || [])];
      const currentData = currentUser.data as any;
      const existsIndex = updatedWaliList.findIndex((w) => w.id === currentData.id || w.username === currentData.username || (w.nip && w.nip === currentData.nip));

      if (existsIndex >= 0) {
        const updatedWali = {
          ...updatedWaliList[existsIndex],
          nama: cleanNama || updatedWaliList[existsIndex].nama,
          username: cleanUsername || updatedWaliList[existsIndex].username,
          password: cleanPassword,
          foto: fotoBase64,
          jabatan: cleanJabatan,
        };
        updatedWaliList[existsIndex] = updatedWali;
        onUpdateSession({ role: updatedWali.role || 'wali', data: updatedWali });
      } else {
        const newWali = {
          id: currentData.id || 'WAL_' + Date.now(),
          nip: currentData.nip || cleanUsername,
          nama: cleanNama,
          username: cleanUsername,
          password: cleanPassword,
          noHp: currentData.noHp || '',
          role: currentUser.role || 'wali',
          foto: fotoBase64,
          jabatan: cleanJabatan,
        };
        updatedWaliList.push(newWali);
        onUpdateSession({ role: newWali.role || 'wali', data: newWali });
      }

      nextAppData.waliKelas = updatedWaliList;
    }

    onUpdateAppData(nextAppData);
    onShowToast('Pengaturan Akun & Password berhasil diperbarui!', 'success');
  };

  const getRoleLabel = () => {
    switch (currentUser.role) {
      case 'admin':
        return 'Administrator';
      case 'kesiswaan':
        return 'Kesiswaan / BP BK';
      case 'kurikulum':
        return 'WKS Kurikulum';
      case 'hubin':
        return 'WKS Hubin';
      case 'guru':
      case 'user':
        return 'Guru';
      case 'wali':
        return 'Wali Kelas';
      case 'murid':
      case 'siswa':
        return 'Murid / Siswa';
      default:
        return 'Pengguna';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <PageHeader
        icon={User}
        title={`Pengaturan Akun Saya (${getRoleLabel()})`}
        description="Kelola nama lengkap, username, password login, dan foto profil akun Anda."
        badge="Profil Pengguna"
      />

      <form onSubmit={handleSubmit} className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800">
          <div className="text-center shrink-0">
            {fotoBase64 ? (
              <img src={fotoBase64} alt="Foto Profil" className="w-20 h-20 rounded-full object-cover mx-auto border border-slate-200 dark:border-slate-700" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 flex items-center justify-center text-2xl font-bold mx-auto">
                <UserCog className="w-10 h-10" />
              </div>
            )}
          </div>
          <div className="space-y-2 text-center sm:text-left">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-200">Foto Profil Akun</label>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
              <input
                type="file"
                accept="image/*"
                onChange={handleFotoUpload}
                className="text-xs text-slate-500 dark:text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 dark:file:bg-blue-950 dark:file:text-blue-300 hover:file:bg-blue-100 cursor-pointer"
              />
              {fotoBase64 && (
                <button
                  type="button"
                  onClick={() => setFotoBase64('')}
                  className="px-3 py-2 bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-300 hover:bg-rose-100 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer"
                  title="Hapus Foto"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Hapus Foto</span>
                </button>
              )}
            </div>
            <p className="text-[10px] text-slate-400">Format: PNG, JPG, GIF (Maks 1MB)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-2">Nama Lengkap Pengguna</label>
            <input
              type="text"
              required
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              className="w-full py-3 px-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-2">Jabatan / Instansi</label>
            <input
              type="text"
              required
              value={jabatan}
              onChange={(e) => setJabatan(e.target.value)}
              className="w-full py-3 px-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Contoh: Wali Kelas X PPLG 1 / Guru Mapel"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-2">Username Login</label>
            <input
              type="text"
              required
              disabled={currentUser.role !== 'admin'}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full py-3 px-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-70 disabled:cursor-not-allowed disabled:bg-slate-100/80 dark:disabled:bg-slate-800/50"
            />
            {currentUser.role !== 'admin' && (
              <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold mt-1.5 flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 shrink-0" />
                <span>Username hanya dapat diubah oleh Administrator Utama.</span>
              </p>
            )}
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-2">Password Baru</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full py-3 px-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            type="submit"
            className="px-6 py-3 bg-theme-primary hover:bg-theme-primary-dark text-white font-bold rounded-2xl text-xs shadow-lg shadow-theme-primary/30 transition flex items-center gap-2 cursor-pointer"
          >
            <UserCheck className="w-4 h-4" />
            <span>Simpan Perubahan Akun</span>
          </button>
        </div>
      </form>

      {currentUser.role === 'admin' && (
        <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-500" />
                <span>Sertifikasi Otomatis Metrik Laporan (Golden Dataset A–E)</span>
              </h3>
              <p className="text-xs text-slate-400">Verifikasi kepatuhan matematis rumus statistik & proteksi regresi pelaporan secara real-time.</p>
            </div>
            <button
              type="button"
              onClick={() => {
                setIsRunningTests(true);
                setTimeout(() => {
                  const res = runAutomatedGoldenDatasetSuite();
                  setTestResults(res);
                  setIsRunningTests(false);
                  onShowToast('Sertifikasi otomatis Golden Dataset selesai dijalankan!', 'success');
                }, 600);
              }}
              disabled={isRunningTests}
              className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-300 disabled:opacity-50 font-bold rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Activity className={`w-4 h-4 ${isRunningTests ? 'animate-spin' : ''}`} />
              <span>{isRunningTests ? 'Menjalankan...' : 'Jalankan Sertifikasi'}</span>
            </button>
          </div>

          {testResults ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {testResults.map((test, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3">
                    <div className="flex items-start justify-between">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100">{test.datasetName}</span>
                      {test.passed ? (
                        <span className="px-2 py-1 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-lg text-[10px] font-extrabold flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>PASS</span>
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-300 rounded-lg text-[10px] font-extrabold flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>FAIL</span>
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[10px]">
                      <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <div className="text-slate-400">Siswa</div>
                        <div className="font-bold text-slate-700 dark:text-slate-200">{test.metrics.totalStudents}</div>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <div className="text-slate-400">Exp Events</div>
                        <div className="font-bold text-slate-700 dark:text-slate-200">{test.metrics.expectedEvents}</div>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <div className="text-slate-400">Rec Events</div>
                        <div className="font-bold text-slate-700 dark:text-slate-200">{test.metrics.recordedEvents}</div>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <div className="text-slate-400">Rec Days</div>
                        <div className="font-bold text-slate-700 dark:text-slate-200">{test.metrics.recordedDays}</div>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <div className="text-slate-400">Unfilled</div>
                        <div className="font-bold text-slate-700 dark:text-slate-200">{test.metrics.unfilledEvents}</div>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <div className="text-slate-400">% Rate</div>
                        <div className="font-bold text-slate-700 dark:text-slate-200">{test.metrics.attendanceRate.toFixed(2)}%</div>
                      </div>
                    </div>

                    {test.errors.length > 0 && (
                      <div className="p-2.5 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-950 rounded-xl space-y-1">
                        <div className="text-[10px] font-bold text-rose-600 dark:text-rose-400">Detail Kesalahan:</div>
                        {test.errors.map((err, errIdx) => (
                          <div key={errIdx} className="text-[9px] text-rose-500 font-semibold">• {err}</div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 text-center py-6">
              <p className="text-xs text-slate-400 font-medium">Belum ada uji sertifikasi yang dijalankan. Klik tombol "Jalankan Sertifikasi" di atas untuk memulai audit otomatis.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
