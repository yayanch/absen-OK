import React from 'react';
import {
  Clock,
  BookOpen,
  QrCode,
  ClipboardCheck,
  FileText,
  UserCheck,
  Calendar,
  CheckCircle2,
  Bell,
  Activity,
  Users,
  ChevronRight,
} from 'lucide-react';
import { AppData, UserSession, ViewType } from '../../types';
import { formatDateIndo } from '../../utils/helpers';
import { RoleQuickActions } from './RoleQuickActions';
import { TeacherScheduleWidget } from './TeacherScheduleWidget';
import { PageHeader, StatCard } from '../common/UIComponents';

interface GuruDashboardViewProps {
  appData: AppData;
  currentUser: UserSession;
  selectedDate: string;
  setSelectedDate: (d: string) => void;
  hadirCount: number;
  totalStudents: number;
  hadirPercentage: string;
  recentLogs: any[];
  onNavigateToInput: (kelasId?: string) => void;
  onNavigateView: (view: ViewType) => void;
}

export const GuruDashboardView: React.FC<GuruDashboardViewProps> = ({
  appData,
  currentUser,
  selectedDate,
  setSelectedDate,
  hadirCount,
  totalStudents,
  hadirPercentage,
  recentLogs,
  onNavigateToInput,
  onNavigateView,
}) => {
  return (
    <div className="space-y-6">
      <PageHeader
        icon={Calendar}
        title={`Selamat Datang, ${currentUser.data.nama}`}
        description="Jadwal mengajar dan pengisian presensi kelas yang Anda ajar hari ini."
        badge={formatDateIndo(selectedDate)}
        actions={
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold cursor-pointer"
          />
        }
      />

      {/* Quick Actions Guru */}
      <RoleQuickActions
        role="guru"
        onNavigateView={onNavigateView}
        onNavigateToInput={() => onNavigateToInput()}
      />

      {/* Ringkasan Kehadiran Sesi Guru */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          label="Siswa Hadir"
          value={hadirCount}
          icon={UserCheck}
          variant="success"
        />
        <StatCard
          label="Belum Presensi"
          value={Math.max(0, totalStudents - hadirCount)}
          icon={Users}
          variant="neutral"
        />
        <StatCard
          label="Persentase Kehadiran"
          value={`${hadirPercentage}%`}
          icon={Activity}
          variant="primary"
        />
      </div>

      {/* Widget Utama Guru: Jadwal Mengajar Hari Ini */}
      <TeacherScheduleWidget
        appData={appData}
        currentUser={currentUser}
        selectedDate={selectedDate}
        onNavigateToInput={onNavigateToInput}
        onNavigateView={onNavigateView}
      />

      {/* Presensi Terakhir & Notifikasi */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Presensi Terakhir */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 md:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-extrabold text-slate-800 dark:text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-theme-primary" />
              <span>Aktivitas Presensi Terakhir</span>
            </h3>
            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">
              Real-time
            </span>
          </div>

          <div className="space-y-2">
            {recentLogs.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs">Belum ada catatan presensi hari ini.</div>
            ) : (
              recentLogs.slice(0, 4).map((log) => (
                <div key={log.id} className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-slate-800 dark:text-white">{log.nama}</div>
                    <div className="text-[10px] text-slate-400">{log.kelas} • {log.waktu}</div>
                  </div>
                  <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black ${log.bg}`}>{log.statusLabel}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Notifikasi Pengumuman Guru */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 md:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-extrabold text-slate-800 dark:text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-amber-500" />
              <span>Notifikasi &amp; Pengumuman</span>
            </h3>
          </div>

          <div className="p-4 bg-amber-50/80 dark:bg-amber-950/40 rounded-2xl border border-amber-200 dark:border-amber-800/60 text-xs text-amber-950 dark:text-amber-200 space-y-1">
            <div className="font-extrabold flex items-center gap-1.5">
              <span>📌 Pengingat Pengisian Jam Ke-1</span>
            </div>
            <p className="text-[11px] opacity-90 leading-relaxed">
              Mohon memastikan seluruh siswa melakukan pemindaian QR Code atau mengisikan status presensi manual sebelum jam pembelajaran berlangsung.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
