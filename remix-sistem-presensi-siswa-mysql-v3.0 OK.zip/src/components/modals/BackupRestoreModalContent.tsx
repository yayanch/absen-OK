import React, { useRef } from 'react';
import { Laptop, Download, Upload, HardDrive, ShieldCheck } from 'lucide-react';
import { AppData } from '../../types';
import { getTodayString, saveAppData } from '../../utils/helpers';

interface BackupRestoreModalContentProps {
  appData: AppData;
  onUpdateAppData: (updated: AppData) => void;
  onCloseModal: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'warning' | 'info') => void;
  onConfirmModal?: (
    title: string,
    message: string,
    type: 'danger' | 'warning' | 'info' | 'emerald',
    onConfirm: () => void
  ) => void;
}

export const BackupRestoreModalContent: React.FC<BackupRestoreModalContentProps> = ({
  appData,
  onUpdateAppData,
  onCloseModal,
  onShowToast,
  onConfirmModal,
}) => {
  const pcFileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadPcBackup = () => {
    try {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(appData, null, 2));
      const downloadAnchor = document.createElement('a');
      const dateToday = getTodayString();
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `Backup_Presensi_PC_${dateToday}.bak`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      onShowToast('Berkas backup PC (.bak) berhasil diunduh ke komputer Anda!', 'success');
    } catch (e) {
      onShowToast('Gagal mengunduh berkas backup PC!', 'error');
    }
  };

  const handleRestorePcBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsedData = JSON.parse(evt.target?.result as string);
        if (!parsedData || typeof parsedData !== 'object' || !parsedData.jurusan || !parsedData.siswa) {
          onShowToast('Format berkas backup PC tidak valid!', 'error');
          return;
        }

        const performRestore = () => {
          const restoredData = { ...appData, ...parsedData };
          onUpdateAppData(restoredData);
          saveAppData(restoredData);
          onCloseModal();
          onShowToast('Data sistem berhasil dipulihkan dari berkas backup PC!', 'success');
        };

        if (onConfirmModal) {
          onConfirmModal(
            'Restore Data dari PC',
            `Apakah Anda yakin ingin memulihkan data dari berkas "${file.name}"? Data saat ini di sistem akan diperbarui secara otomatis.`,
            'warning',
            performRestore
          );
        } else {
          performRestore();
        }
      } catch (err) {
        onShowToast('Gagal membaca berkas backup PC!', 'error');
      }
    };
    reader.readAsText(file);
    if (pcFileInputRef.current) pcFileInputRef.current.value = '';
  };

  return (
    <div className="space-y-5 text-xs">
      {/* PC / Laptop Local Backup & Restore */}
      <div className="p-4 bg-blue-50/60 border border-blue-200 rounded-2xl dark:bg-slate-800/80 dark:border-slate-700">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 flex items-center justify-center text-lg font-bold shrink-0">
            <Laptop className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-1.5">
              <span>Backup &amp; Restore Perangkat PC / Komputer</span>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 text-[10px] font-bold flex items-center gap-1">
                <HardDrive className="w-3 h-3" /> Luring (Offline)
              </span>
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Simpan berkas cadangan database langsung ke memori komputer (PC) Anda atau pulihkan data dari berkas cadangan PC.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mt-2">
          {/* Download PC Backup */}
          <div className="p-3 bg-white dark:bg-slate-900/70 rounded-xl border border-blue-100 dark:border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-blue-700 dark:text-blue-300 font-bold text-xs mb-1">
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Cadangan PC</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                Unduh berkas cadangan database (`.bak`) berisi seluruh data sekolah, kelas, siswa, dan riwayat presensi ke harddisk PC.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadPcBackup}
              className="w-full py-2.5 px-3 bg-theme-primary hover:bg-theme-primary-dark text-white font-bold rounded-xl shadow-sm transition flex items-center justify-center gap-2 text-xs"
            >
              <Download className="w-4 h-4" />
              <span>Simpan Backup ke PC (.bak)</span>
            </button>
          </div>

          {/* Restore PC Backup */}
          <div className="p-3 bg-white dark:bg-slate-900/70 rounded-xl border border-amber-100 dark:border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-400 font-bold text-xs mb-1">
                <Upload className="w-3.5 h-3.5" />
                <span>Pulihkan dari PC</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                Pilih berkas cadangan (`.bak` / `.json`) dari PC untuk mengembalikan seluruh database ke kondisi semula.
              </p>
            </div>
            <div>
              <input
                type="file"
                ref={pcFileInputRef}
                accept=".bak,.json,.dat"
                onChange={handleRestorePcBackup}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => pcFileInputRef.current?.click()}
                className="w-full py-2.5 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-sm transition flex items-center justify-center gap-2 text-xs"
              >
                <Upload className="w-4 h-4" />
                <span>Unggah &amp; Pulihkan File PC</span>
              </button>
            </div>
          </div>
        </div>

        <div className="mt-3 p-2.5 bg-blue-100/50 dark:bg-slate-900/50 rounded-xl flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <span>Berkas cadangan PC yang diunggah akan otomatis memulihkan seluruh data sekolah, kelas, siswa, dan presensi.</span>
        </div>
      </div>

      <div className="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
        <button
          type="button"
          onClick={onCloseModal}
          className="px-5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
        >
          Tutup
        </button>
      </div>
    </div>
  );
};

