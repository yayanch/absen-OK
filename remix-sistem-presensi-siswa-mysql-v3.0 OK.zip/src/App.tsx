import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Lock } from 'lucide-react';
import { motion } from 'motion/react';
import {
  AppData,
  UserSession,
  ViewType,
  WaliKelas,
  ThemeOption,
  PageHeaderBackgroundOption,
  SekolahConfig,
  SyncResult
} from './types';
import {
  loadAppData,
  saveAppData,
  commitAppDataToServer,
  loadSessionUser,
  saveSessionUser,
  mergeChatMessages,
  mergePelanggaran,
  mergeHomeVisits
} from './utils/helpers';
import { DEMO_DATASET } from './data/initialData';

import { LoginView } from './components/LoginView';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ToastContainer, ToastMessage } from './components/ToastContainer';
import { ConfirmModal, ConfirmState } from './components/ConfirmModal';
import { GeneralModal } from './components/GeneralModal';
import { Footer } from './components/Footer';
import { BackToTop } from './components/BackToTop';

const DashboardView = React.lazy(() => import('./components/views/DashboardView').then(m => ({ default: m.DashboardView })));
const InputPresensiView = React.lazy(() => import('./components/views/InputPresensiView').then(m => ({ default: m.InputPresensiView })));
const HomeVisitView = React.lazy(() => import('./components/views/HomeVisitView').then(m => ({ default: m.HomeVisitView })));
const PelanggaranView = React.lazy(() => import('./components/views/PelanggaranView').then(m => ({ default: m.PelanggaranView })));
const RekapHarianView = React.lazy(() => import('./components/views/RekapHarianView').then(m => ({ default: m.RekapHarianView })));
const RekapMingguanView = React.lazy(() => import('./components/views/RekapMingguanView').then(m => ({ default: m.RekapMingguanView })));
const RekapBulananView = React.lazy(() => import('./components/views/RekapBulananView').then(m => ({ default: m.RekapBulananView })));
const RekapKetidakhadiranTertinggiView = React.lazy(() => import('./components/views/RekapKetidakhadiranTertinggiView').then(m => ({ default: m.RekapKetidakhadiranTertinggiView })));
const MasterJurusanView = React.lazy(() => import('./components/views/MasterJurusanView').then(m => ({ default: m.MasterJurusanView })));
const MasterGuruView = React.lazy(() => import('./components/views/MasterGuruView').then(m => ({ default: m.MasterGuruView })));
const MasterMataPelajaranView = React.lazy(() => import('./components/views/MasterMataPelajaranView').then(m => ({ default: m.MasterMataPelajaranView })));
const MasterKelasView = React.lazy(() => import('./components/views/MasterKelasView').then(m => ({ default: m.MasterKelasView })));
const MasterSiswaView = React.lazy(() => import('./components/views/MasterSiswaView').then(m => ({ default: m.MasterSiswaView })));
const HariLiburView = React.lazy(() => import('./components/views/HariLiburView').then(m => ({ default: m.HariLiburView })));
const PengaturanSekolahView = React.lazy(() => import('./components/views/PengaturanSekolahView').then(m => ({ default: m.PengaturanSekolahView })));
const PengaturanTemaView = React.lazy(() => import('./components/views/PengaturanTemaView').then(m => ({ default: m.PengaturanTemaView })));
const PengaturanAdminView = React.lazy(() => import('./components/views/PengaturanAdminView').then(m => ({ default: m.PengaturanAdminView })));
const MasterUserView = React.lazy(() => import('./components/views/MasterUserView').then(m => ({ default: m.MasterUserView })));
const DataDemoView = React.lazy(() => import('./components/views/DataDemoView').then(m => ({ default: m.DataDemoView })));
const IntegrasiMySQLView = React.lazy(() => import('./components/views/IntegrasiMySQLView').then(m => ({ default: m.IntegrasiMySQLView })));
const DatabaseTrafficView = React.lazy(() => import('./components/views/DatabaseTrafficView').then(m => ({ default: m.DatabaseTrafficView })));
const CetakKartuQrView = React.lazy(() => import('./components/views/CetakKartuQrView').then(m => ({ default: m.CetakKartuQrView })));
const LiveChatView = React.lazy(() => import('./components/views/LiveChatView').then(m => ({ default: m.LiveChatView })));
import { LiveChatWidget } from './components/chat/LiveChatWidget';
const OfflineView = React.lazy(() => import('./components/views/OfflineView').then(m => ({ default: m.OfflineView })));
const PortalMuridView = React.lazy(() => import('./components/views/PortalMuridView').then(m => ({ default: m.PortalMuridView })));
const JadwalShiftView = React.lazy(() => import('./components/views/JadwalShiftView').then(m => ({ default: m.JadwalShiftView })));
const AuditLogsView = React.lazy(() => import('./components/views/AuditLogsView').then(m => ({ default: m.AuditLogsView })));
const IntrusionDetectionView = React.lazy(() => import('./components/views/IntrusionDetectionView').then(m => ({ default: m.IntrusionDetectionView })));

import { BackupRestoreModalContent } from './components/modals/BackupRestoreModalContent';
import { ServerQrDisplayModal } from './components/modals/ServerQrDisplayModal';

export default function App() {
  const getInitialView = (): ViewType => {
    if (typeof window !== 'undefined') {
      if (window.history.state && window.history.state.view) {
        return window.history.state.view as ViewType;
      }
      const hash = window.location.hash.replace('#', '');
      if (hash) {
        return hash as ViewType;
      }
    }
    const savedUser = loadSessionUser();
    return 'dashboard';
  };

  const [appData, setAppData] = useState<AppData>(loadAppData);
  const [currentUser, setCurrentUser] = useState<UserSession | null>(loadSessionUser);
  const [currentView, setCurrentView] = useState<ViewType>(getInitialView);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsInitializing(false);
    }, 450);
    return () => clearTimeout(timer);
  }, []);

  const handleNavigate = (view: ViewType, replace = false) => {
    if (view === currentView) return;
    setCurrentView(view);
    if (typeof window !== 'undefined') {
      if (replace) {
        window.history.replaceState({ view }, '', `#${view}`);
      } else if (window.history.state?.view !== view) {
        window.history.pushState({ view }, '', `#${view}`);
      }
    }
  };

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const currentHash = window.location.hash.replace('#', '');
    const initialView = (window.history.state?.view || currentHash || currentView) as ViewType;
    if (!window.history.state || window.history.state.view !== initialView) {
      window.history.replaceState({ view: initialView }, '', `#${initialView}`);
    }

    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.view) {
        setCurrentView(event.state.view as ViewType);
      } else {
        const hash = window.location.hash.replace('#', '');
        if (hash) {
          setCurrentView(hash as ViewType);
        } else {
          setCurrentView('dashboard');
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);
  const [isServerQrModalOpen, setIsServerQrModalOpen] = useState<boolean>(false);
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() => {
    try {
      const savedData = localStorage.getItem('presensi_app_data');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        if (parsed?.sekolah?.sidebarBehavior === 'expanded') {
          return true;
        }
        if (parsed?.sekolah?.sidebarBehavior === 'collapsed') {
          return false;
        }
      }
    } catch (e) {}
    return false;
  });
  const [selectedInputKelasId, setSelectedInputKelasId] = useState<string | undefined>(undefined);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('theme') === 'dark';
  });

  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');
  const saveTimeoutRef = useRef<any>(null);
  const lastLocalChangeRef = useRef<number>(0);

  const triggerSaveStatus = () => {
    setSaveStatus('saving');
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(() => {
      setSaveStatus('saved');
    }, 900);
  };

  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [ignoreOffline, setIgnoreOffline] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setIgnoreOffline(false);
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Global Realtime Sync with Server & MySQL for Dev and Preview links (with conditional 304 caching)
  const lastEtagRef = useRef<string>('');

  useEffect(() => {
    let isMounted = true;

    const fetchGlobalState = async () => {
      try {
        const host = localStorage.getItem('mysql_host') || '';
        const database = localStorage.getItem('mysql_database') || '';
        const user = localStorage.getItem('mysql_user') || '';
        const password = localStorage.getItem('mysql_password') || '';
        const port = localStorage.getItem('mysql_port') || '3306';

        const headers: Record<string, string> = {};
        if (lastEtagRef.current) {
          headers['If-None-Match'] = lastEtagRef.current;
        }
        if (host && database && user) {
          headers['x-mysql-host'] = host;
          headers['x-mysql-database'] = database;
          headers['x-mysql-user'] = user;
          headers['x-mysql-password'] = password;
          headers['x-mysql-port'] = port;
        }

        const res = await fetch('/api/global-state', { headers });
        if (res.status === 304) {
          // Data is completely unchanged, zero bytes transferred
          return;
        }
        if (!res.ok) return;

        const etag = res.headers.get('ETag');
        if (etag) {
          lastEtagRef.current = etag;
        }

        const data = await res.json();
        if (data.success && isMounted) {
          if (Date.now() - lastLocalChangeRef.current < 4000) {
            return;
          }
          if (data.appData) {
            setAppData((prev) => {
              // Merge local optimistic items to prevent data from disappearing during sync
              const mergedMessages = mergeChatMessages(prev.chatMessages, data.appData.chatMessages);
              const allDeletedPelanggaran = Array.from(new Set([...(prev.deletedPelanggaranIds || []), ...(data.appData.deletedPelanggaranIds || [])]));
              const allDeletedHomeVisits = Array.from(new Set([...(prev.deletedHomeVisitIds || []), ...(data.appData.deletedHomeVisitIds || [])]));
              const mergedPelanggaran = mergePelanggaran(prev.pelanggaran, data.appData.pelanggaran, allDeletedPelanggaran);
              const mergedHomeVisits = mergeHomeVisits(prev.homeVisits, data.appData.homeVisits, allDeletedHomeVisits);
              const targetAppData = {
                ...data.appData,
                chatMessages: mergedMessages,
                pelanggaran: mergedPelanggaran,
                homeVisits: mergedHomeVisits,
                deletedPelanggaranIds: allDeletedPelanggaran,
                deletedHomeVisitIds: allDeletedHomeVisits,
              };
              const currentStr = JSON.stringify(prev);
              const newStr = JSON.stringify(targetAppData);
              if (currentStr !== newStr) {
                try {
                  localStorage.setItem('presensi_app_data', newStr);
                } catch (e) {}
                return targetAppData;
              }
              return prev;
            });
          }
          if (data.mysqlConfig) {
            if (data.mysqlConfig.host) localStorage.setItem('mysql_host', data.mysqlConfig.host);
            if (data.mysqlConfig.port) localStorage.setItem('mysql_port', data.mysqlConfig.port);
            if (data.mysqlConfig.user) localStorage.setItem('mysql_user', data.mysqlConfig.user);
            if (data.mysqlConfig.password !== undefined) localStorage.setItem('mysql_password', data.mysqlConfig.password);
            if (data.mysqlConfig.database) localStorage.setItem('mysql_database', data.mysqlConfig.database);
          }
        }
      } catch (e) {
        // silent
      }
    };

    fetchGlobalState();

    // Poll every 3 seconds for lightning-fast real-time synchronization across devices and views
    const interval = setInterval(fetchGlobalState, 3000);

    const handleFocus = () => fetchGlobalState();
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        fetchGlobalState();
      }
    };
    const handleCustomDataUpdate = (e: Event) => {
      // If event has detail (local data update), apply immediately without waiting for network response
      const customEvent = e as CustomEvent;
      if (customEvent.detail && isMounted) {
        setAppData((prev) => {
          const mergedMessages = mergeChatMessages(prev.chatMessages, customEvent.detail.chatMessages);
          return {
            ...customEvent.detail,
            chatMessages: mergedMessages,
          };
        });
      }
      fetchGlobalState();
    };

    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('presensi-data-updated', handleCustomDataUpdate as EventListener);

    const channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('presensi_app_sync') : null;
    if (channel) {
      channel.onmessage = () => {
        fetchGlobalState();
      };
    }

    return () => {
      isMounted = false;
      clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('presensi-data-updated', handleCustomDataUpdate as EventListener);
      if (channel) {
        channel.close();
      }
    };
  }, []);

  // Real-time Chat Sync poller (every 1.5 seconds) to ensure deletions & new messages instantly reflect across all devices/recipients
  useEffect(() => {
    let isMounted = true;
    const syncChatMessages = async () => {
      try {
        const res = await fetch('/api/chat/messages');
        if (!res.ok) return;
        const data = await res.json();
        if (data.success && Array.isArray(data.chatMessages) && isMounted) {
          setAppData((prev) => {
            const currentMsgs = prev.chatMessages || [];
            const merged = mergeChatMessages(currentMsgs, data.chatMessages);
            if (JSON.stringify(currentMsgs) !== JSON.stringify(merged)) {
              return {
                ...prev,
                chatMessages: merged,
              };
            }
            return prev;
          });
        }
      } catch (e) {}
    };

    const chatInterval = setInterval(syncChatMessages, 1500);
    return () => {
      isMounted = false;
      clearInterval(chatInterval);
    };
  }, []);

  // System Theme / Dark Mode Sync Effect
  useEffect(() => {
    const mode = appData.sekolah?.themeMode || (isDarkMode ? 'dark' : 'light');
    
    if (mode === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const applySystemTheme = (e: MediaQueryListEvent | MediaQueryList) => {
        if (e.matches) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      };
      applySystemTheme(mediaQuery);
      const listener = (e: MediaQueryListEvent) => applySystemTheme(e);
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    } else if (mode === 'dark') {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [appData.sekolah?.themeMode, isDarkMode]);

  // Design Tokens & Attributes Sync Effect
  useEffect(() => {
    const currentTheme = appData.sekolah?.themePreset || appData.sekolah?.theme || 'school_blue';
    const currentSidebar = appData.sekolah?.sidebarTheme || 'royal';
    const currentFont = appData.sekolah?.fontTheme || 'inter';
    const currentDensity = appData.sekolah?.density || 'comfortable';
    const currentRadius = appData.sekolah?.componentRadius || 'standard';
    const currentShadow = appData.sekolah?.shadowStyle || 'minimal';
    const currentPageHeaderBg = appData.sekolah?.pageHeaderBackground || 'gradient_royal';

    document.documentElement.setAttribute('data-theme', currentTheme);
    document.documentElement.setAttribute('data-sidebar-theme', currentSidebar);
    document.documentElement.setAttribute('data-font', currentFont);
    document.documentElement.setAttribute('data-density', currentDensity);
    document.documentElement.setAttribute('data-radius', currentRadius);
    document.documentElement.setAttribute('data-shadow', currentShadow);
    document.documentElement.setAttribute('data-page-header-bg', currentPageHeaderBg);

    if (appData.sekolah?.primaryColor) {
      document.documentElement.style.setProperty('--theme-primary', appData.sekolah.primaryColor);
    } else {
      document.documentElement.style.removeProperty('--theme-primary');
    }

    // Page Header Background & Automatic Contrast Token Mapping
    const pageHeaderBgMap: Record<PageHeaderBackgroundOption, {
      bg: string;
      title: string;
      subtitle: string;
      badgeBg: string;
      badgeBorder: string;
      badgeText: string;
    }> = {
      white: {
        bg: '#FFFFFF',
        title: '#0F172A',
        subtitle: '#64748B',
        badgeBg: '#FFFFFF',
        badgeBorder: '#E2E8F0',
        badgeText: '#334155',
      },
      royal: {
        bg: '#1646E3',
        title: '#FFFFFF',
        subtitle: 'rgba(255, 255, 255, 0.80)',
        badgeBg: 'rgba(255, 255, 255, 0.12)',
        badgeBorder: 'rgba(255, 255, 255, 0.18)',
        badgeText: '#FFFFFF',
      },
      deep_blue: {
        bg: '#1E3A8A',
        title: '#FFFFFF',
        subtitle: 'rgba(255, 255, 255, 0.80)',
        badgeBg: 'rgba(255, 255, 255, 0.12)',
        badgeBorder: 'rgba(255, 255, 255, 0.18)',
        badgeText: '#FFFFFF',
      },
      indigo: {
        bg: '#4338CA',
        title: '#FFFFFF',
        subtitle: 'rgba(255, 255, 255, 0.80)',
        badgeBg: 'rgba(255, 255, 255, 0.12)',
        badgeBorder: 'rgba(255, 255, 255, 0.18)',
        badgeText: '#FFFFFF',
      },
      slate: {
        bg: '#334155',
        title: '#FFFFFF',
        subtitle: 'rgba(255, 255, 255, 0.80)',
        badgeBg: 'rgba(255, 255, 255, 0.12)',
        badgeBorder: 'rgba(255, 255, 255, 0.18)',
        badgeText: '#FFFFFF',
      },
      soft_blue: {
        bg: '#EFF6FF',
        title: '#0F172A',
        subtitle: '#64748B',
        badgeBg: '#FFFFFF',
        badgeBorder: '#E2E8F0',
        badgeText: '#334155',
      },
      gradient_royal: {
        bg: 'linear-gradient(135deg, #1646E3 0%, #4338CA 100%)',
        title: '#FFFFFF',
        subtitle: 'rgba(255, 255, 255, 0.80)',
        badgeBg: 'rgba(255, 255, 255, 0.12)',
        badgeBorder: 'rgba(255, 255, 255, 0.18)',
        badgeText: '#FFFFFF',
      },
    };

    const headerConfig = pageHeaderBgMap[currentPageHeaderBg] || pageHeaderBgMap.gradient_royal;
    document.documentElement.style.setProperty('--page-header-bg', headerConfig.bg);
    document.documentElement.style.setProperty('--page-header-title', headerConfig.title);
    document.documentElement.style.setProperty('--page-header-subtitle', headerConfig.subtitle);
    document.documentElement.style.setProperty('--page-header-badge-bg', headerConfig.badgeBg);
    document.documentElement.style.setProperty('--page-header-badge-border', headerConfig.badgeBorder);
    document.documentElement.style.setProperty('--page-header-badge-text', headerConfig.badgeText);

    // Backward compatibility tokens
    document.documentElement.style.setProperty('--page-title-color', headerConfig.title);
    document.documentElement.style.setProperty('--page-subtitle-color', headerConfig.subtitle);
  }, [
    appData.sekolah?.themePreset,
    appData.sekolah?.theme,
    appData.sekolah?.sidebarTheme,
    appData.sekolah?.fontTheme,
    appData.sekolah?.density,
    appData.sekolah?.componentRadius,
    appData.sekolah?.shadowStyle,
    appData.sekolah?.primaryColor,
    appData.sekolah?.pageHeaderBackground,
  ]);

  useEffect(() => {
    const faviconUrl = appData.sekolah?.favicon !== undefined && appData.sekolah?.favicon !== '' 
      ? appData.sekolah.favicon 
      : (appData.sekolah?.logo || '');
    
    let link: HTMLLinkElement | null = document.querySelector("link[rel*='icon']");
    if (!link) {
      link = document.createElement('link');
      link.rel = 'shortcut icon';
      document.head.appendChild(link);
    }
    if (faviconUrl) {
      link.href = faviconUrl;
    } else {
      link.removeAttribute('href');
    }

    if (appData.sekolah?.browserTitle) {
      document.title = appData.sekolah.browserTitle;
    } else if (appData.sekolah?.nama) {
      document.title = `${appData.sekolah.nama} - Absensi Siswa`;
    }
  }, [appData.sekolah?.favicon, appData.sekolah?.logo, appData.sekolah?.nama, appData.sekolah?.browserTitle]);

  const toggleTheme = () => {
    setIsDarkMode((prev) => !prev);
  };

  const handleSelectColorTheme = (themeId: ThemeOption) => {
    triggerSaveStatus();
    const updatedSekolah = {
      ...appData.sekolah,
      theme: themeId,
      themePreset: themeId,
      primaryColor: themeId === 'school_blue' ? '#2563EB' : appData.sekolah.primaryColor,
    };
    const updatedAppData = { ...appData, sekolah: updatedSekolah };
    setAppData(updatedAppData);
    document.documentElement.setAttribute('data-theme', themeId);
    try {
      localStorage.setItem('presensi_app_data', JSON.stringify(updatedAppData));
    } catch (e) {
      console.error(e);
    }
    saveAppData(updatedAppData);
    const themeNames: Record<string, string> = {
      school_blue: 'SMKN 6 Garut (School Blue)',
      professional: 'Professional Enterprise',
      ocean: 'Biru Ocean',
      emerald: 'Hijau Zamrud',
      indigo: 'Nila Indigo',
      violet: 'Ungu Violet',
      slate: 'Abu Slate',
    };
    showToast(`Tema warna berhasil diubah ke ${themeNames[themeId] || themeId}!`, 'success');
  };

  // Toast System
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 4);
    const newToast: ToastMessage = { id, message, type };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Confirmation Modal System
  const [confirmState, setConfirmState] = useState<ConfirmState>({
    isOpen: false,
    title: '',
    message: '',
    type: 'warning',
    onConfirm: () => {},
  });

  const openConfirmModal = (
    title: string,
    message: string,
    type: 'danger' | 'warning' | 'info' | 'emerald',
    onConfirm: () => void
  ) => {
    setConfirmState({
      isOpen: true,
      title,
      message,
      type,
      onConfirm,
    });
  };

  const closeConfirmModal = () => {
    setConfirmState((prev) => ({ ...prev, isOpen: false }));
  };

  // General Modal System
  const [generalModal, setGeneralModal] = useState<{
    isOpen: boolean;
    title: string;
    content: React.ReactNode;
  }>({
    isOpen: false,
    title: '',
    content: null,
  });

  const openGeneralModal = (title: string, content: React.ReactNode) => {
    setGeneralModal({
      isOpen: true,
      title,
      content,
    });
  };

  const closeGeneralModal = () => {
    setGeneralModal((prev) => ({ ...prev, isOpen: false }));
  };

  // Save State
  const handleUpdateAppData = (updated: AppData | ((prev: AppData) => AppData)) => {
    triggerSaveStatus();
    lastLocalChangeRef.current = Date.now();
    setAppData((prev) => {
      const nextData = typeof updated === 'function' ? updated(prev) : updated;
      saveAppData(nextData);
      return nextData;
    });
  };

  // Dedicated Hardened Server Commit for Attendance View (Prompt 6A.6.1)
  const handleSavePresensiFromView = async (nextAppData: AppData): Promise<SyncResult> => {
    triggerSaveStatus();
    setAppData(nextAppData);
    try {
      localStorage.setItem('presensi_app_data', JSON.stringify(nextAppData));
    } catch (e) {}

    const result = await commitAppDataToServer(nextAppData);
    if (result.success) {
      if (typeof BroadcastChannel !== 'undefined') {
        try {
          const ch = new BroadcastChannel('presensi_app_sync');
          ch.postMessage({ type: 'UPDATE', timestamp: Date.now() });
          ch.close();
        } catch (e) {}
      }
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('presensi-data-updated', { detail: nextAppData }));
      }
    }
    return result;
  };

  const handleUpdateSekolah = (updatedSekolah: Partial<SekolahConfig>) => {
    triggerSaveStatus();
    const updated = {
      ...appData,
      sekolah: {
        ...appData.sekolah,
        ...updatedSekolah,
      },
    };
    setAppData(updated);
    saveAppData(updated);
  };

  // Login & Logout
  const handleLogin = (session: UserSession) => {
    setCurrentUser(session);
    saveSessionUser(session);
    handleNavigate('dashboard', true);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    saveSessionUser(null);
    handleNavigate('dashboard', true);
    showToast('Anda telah keluar dari sistem.', 'info');
  };

  // Reset & Restore Demo
  const handleRestoreDemoData = () => {
    openConfirmModal(
      'Isi / Restore Data Demo',
      'Apakah Anda yakin ingin mengisi data sampel demo? Data jurusan, kelas, wali kelas, siswa, dan sampel presensi bawaan akan dimuat ulang ke sistem.',
      'emerald',
      () => {
        const resetData = JSON.parse(JSON.stringify(DEMO_DATASET));
        handleUpdateAppData(resetData);

        showToast('Data demo berhasil dimuat ulang ke dalam sistem!', 'success');
      }
    );
  };

  const handleResetPresensiData = () => {
    openConfirmModal(
      'Reset Data Presensi',
      'PERINGATAN: Tindakan ini hanya akan MENGHAPUS SELURUH RIWAYAT PRESENSI SISWA. Data Master (Siswa, Kelas, Wali Kelas, Jurusan) tetap tersimpan aman. Lanjutkan?',
      'danger',
      () => {
        const resetPresensiData: AppData = {
          ...appData,
          presensi: {},
        };
        handleUpdateAppData(resetPresensiData);

        showToast('Seluruh riwayat data presensi berhasil direset!', 'success');
      }
    );
  };

  const handleResetAllData = () => {
    openConfirmModal(
      'Reset Seluruh Data',
      'PERINGATAN: Tindakan ini akan MENGHAPUS SELURUH DATA yang tersimpan di aplikasi (Jurusan, Kelas, Wali Kelas, Siswa, dan Presensi). Lanjutkan?',
      'danger',
      () => {
        const emptyData: AppData = {
          sekolah: { ...appData.sekolah },
          admin: { ...appData.admin },
          jurusan: [],
          waliKelas: [],
          kelas: [],
          siswa: [],
          presensi: {},
        };
        handleUpdateAppData(emptyData);

        showToast('Seluruh data sistem telah dibersihkan!', 'info');
      }
    );
  };

  const handleOpenBackupModal = () => {
    openGeneralModal(
      'Backup & Restore Data Sistem',
      <BackupRestoreModalContent
        appData={appData}
        onUpdateAppData={handleUpdateAppData}
        onCloseModal={closeGeneralModal}
        onShowToast={showToast}
        onConfirmModal={openConfirmModal}
      />
    );
  };

  // If initializing, show clean branded loading splash
  if (isInitializing) {
    return (
      <div className="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center text-white z-50 selection:bg-indigo-500">
        <div className="relative flex items-center justify-center mb-5">
          <div className="w-20 h-20 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
          {appData.sekolah?.logo ? (
            <img
              src={appData.sekolah.logo}
              alt="Logo"
              className="w-10 h-10 object-contain absolute"
              onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
            />
          ) : (
            <img
              src="/app-icon.svg"
              alt="Logo"
              className="w-10 h-10 object-contain absolute"
            />
          )}
        </div>
        <h1 className="text-sm font-extrabold tracking-wider text-slate-100 uppercase mb-1">
          {appData.sekolah?.nama || 'Absensi Siswa'}
        </h1>
        <p className="text-xs font-medium text-slate-400 animate-pulse">
          Memuat Sistem Presensi & Kesiswaan...
        </p>
        <div className="w-44 h-1 bg-slate-800 rounded-full overflow-hidden mt-6">
          <div className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-500 animate-pulse w-full rounded-full" />
        </div>
      </div>
    );
  }

  // If offline and not ignored, show Offline page with description and troubleshooting
  if (!isOnline && !ignoreOffline) {
    return (
      <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex flex-col justify-center">
        <OfflineView
          onRetry={() => {
            if (navigator.onLine) {
              setIsOnline(true);
              setIgnoreOffline(false);
            }
          }}
          onContinueOffline={() => setIgnoreOffline(true)}
        />
        <ToastContainer toasts={toasts} onRemove={removeToast} />
      </div>
    );
  }

  // If not logged in, show Login view
  if (!currentUser) {
    return (
      <>
        <LoginView
          appData={appData}
          onLogin={handleLogin}
          onUpdateSekolah={handleUpdateSekolah}
          onUpdateAppData={handleUpdateAppData}
          onShowToast={showToast}
          isDarkMode={isDarkMode}
          onToggleTheme={toggleTheme}
        />
        <ToastContainer toasts={toasts} onRemove={removeToast} />
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-100 antialiased transition-colors relative overflow-x-clip">
      {/* Sidebar Container */}
      <Sidebar
        currentView={currentView}
        currentUser={currentUser}
        sekolah={appData.sekolah}
        appData={appData}
        isOpen={sidebarOpen}
        enableLiveChat={appData.enableLiveChat ?? appData.sekolah?.enableLiveChat ?? true}
        adminPassword={appData.admin?.password || 'admin123'}
        onSwitchView={(v) => handleNavigate(v)}
        onCloseMobile={() => setSidebarOpen(false)}
        onRestoreDemo={handleRestoreDemoData}
        onResetPresensi={handleResetPresensiData}
        onResetAll={handleResetAllData}
        onOpenBackupModal={handleOpenBackupModal}
        onOpenServerQrModal={() => setIsServerQrModalOpen(true)}
      />

      {/* Main Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <Header
          currentUser={currentUser}
          sekolah={appData.sekolah}
          appData={appData}
          isDarkMode={isDarkMode}
          isOnline={isOnline}
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
          onLogout={handleLogout}
          onToggleTheme={toggleTheme}
          onSelectColorTheme={handleSelectColorTheme}
          onNavigate={(v) => handleNavigate(v)}
          onOpenServerQrModal={() => setIsServerQrModalOpen(true)}
          saveStatus={saveStatus}
        />

        <main className="flex-1 p-4 md:p-6 pb-2 md:pb-4">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="w-full h-full"
          >
            <React.Suspense fallback={
              <div className="flex flex-col items-center justify-center min-h-[400px] text-center space-y-4">
                <div className="w-10 h-10 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Memuat Halaman...</p>
              </div>
            }>
              {((currentUser.role === 'murid' &&
              currentView !== 'catatan_pelanggaran' &&
              currentView !== 'live_chat') ||
              currentView === 'portal_murid' ||
              currentView === 'absen_qr' ||
              currentView === 'kartu_pelajar' ||
              currentView === 'rekap_siswa') ? (
              <PortalMuridView
                appData={appData}
                currentUser={currentUser}
                activeTab={
                  currentView === 'absen_qr'
                    ? 'absen_qr'
                    : currentView === 'kartu_pelajar'
                    ? 'kartu_pelajar'
                    : currentView === 'rekap_siswa'
                    ? 'rekap_siswa'
                    : 'overview'
                }
                onUpdateAppData={handleUpdateAppData}
                onUpdateCurrentUser={(session) => {
                  setCurrentUser(session);
                  saveSessionUser(session);
                }}
                onShowToast={showToast}
                onNavigate={(v) => handleNavigate(v)}
              />
            ) : (
              <>
                {currentView === 'jadwal_shift' && (
              <JadwalShiftView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
              />
            )}

            {currentView === 'dashboard' && (
                  <DashboardView
                    appData={appData}
                    currentUser={currentUser}
                    onNavigateToInput={(kelasId) => {
                      setSelectedInputKelasId(kelasId);
                      handleNavigate('presensi_input');
                    }}
                    onNavigateView={(v) => handleNavigate(v)}
                    onUpdateAppData={handleUpdateAppData}
                  />
                )}

            {currentView === 'presensi_input' && (
              <InputPresensiView
                appData={appData}
                currentUser={currentUser}
                initialKelasId={selectedInputKelasId}
                onSavePresensi={handleSavePresensiFromView}
                onShowToast={showToast}
                onConfirmModal={openConfirmModal}
                onOpenServerQrModal={() => setIsServerQrModalOpen(true)}
              />
            )}

            {currentView === 'home_visit' && (
              <HomeVisitView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
                onConfirmModal={openConfirmModal}
              />
            )}

            {currentView === 'catatan_pelanggaran' && (
              <PelanggaranView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
                onConfirmModal={openConfirmModal}
              />
            )}

            {currentView === 'rekap_harian' && (
              <RekapHarianView appData={appData} currentUser={currentUser} />
            )}

            {currentView === 'rekap_mingguan' && (
              <RekapMingguanView appData={appData} currentUser={currentUser} />
            )}

            {currentView === 'rekap_bulanan' && (
              <RekapBulananView appData={appData} currentUser={currentUser} />
            )}

            {currentView === 'rekap_ketidakhadiran_tertinggi' && (
              <RekapKetidakhadiranTertinggiView
                appData={appData}
                currentUser={currentUser}
                onShowToast={showToast}
                onBack={() => handleNavigate('dashboard')}
              />
            )}

            {currentView === 'master_jurusan' && (currentUser.role === 'admin' || currentUser.role === 'kesiswaan' || currentUser.role === 'user' || currentUser.role === 'guru' || currentUser.role === 'kurikulum' || currentUser.role === 'hubin') && (
              <MasterJurusanView
                appData={appData}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onOpenModal={openGeneralModal}
                onCloseModal={closeGeneralModal}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'master_guru' && (currentUser.role === 'admin' || currentUser.role === 'kesiswaan' || currentUser.role === 'user' || currentUser.role === 'guru' || currentUser.role === 'kurikulum' || currentUser.role === 'hubin') && (
              <MasterGuruView
                appData={appData}
                currentUser={currentUser}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onOpenModal={openGeneralModal}
                onCloseModal={closeGeneralModal}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'master_mapel' && (currentUser.role === 'admin' || currentUser.role === 'kesiswaan' || currentUser.role === 'user' || currentUser.role === 'guru' || currentUser.role === 'kurikulum' || currentUser.role === 'hubin') && (
              <MasterMataPelajaranView
                appData={appData}
                currentUser={currentUser}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onOpenModal={openGeneralModal}
                onCloseModal={closeGeneralModal}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'master_user' && (currentUser.role === 'admin') && (
              <MasterUserView
                appData={appData}
                currentUser={currentUser}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onOpenModal={openGeneralModal}
                onCloseModal={closeGeneralModal}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'master_kelas' && (currentUser.role === 'admin' || currentUser.role === 'kesiswaan' || currentUser.role === 'user' || currentUser.role === 'guru' || currentUser.role === 'kurikulum' || currentUser.role === 'hubin') && (
              <MasterKelasView
                appData={appData}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onOpenModal={openGeneralModal}
                onCloseModal={closeGeneralModal}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'master_siswa' && (currentUser.role === 'admin' || currentUser.role === 'kesiswaan' || currentUser.role === 'user' || currentUser.role === 'guru' || currentUser.role === 'kurikulum' || currentUser.role === 'hubin' || currentUser.role === 'wali') && (
              <MasterSiswaView
                appData={appData}
                currentUser={currentUser}
                readOnly={currentUser.role !== 'admin' && currentUser.role !== 'wali'}
                onUpdateAppData={handleUpdateAppData}
                onOpenModal={openGeneralModal}
                onCloseModal={closeGeneralModal}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'hari_libur' && (
              <HariLiburView
                appData={appData}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
                onConfirmModal={openConfirmModal}
              />
            )}

            {currentView === 'audit_logs' && (
              <AuditLogsView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'pengaturan_sekolah' && (
              <PengaturanSekolahView
                appData={appData}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'pengaturan_tema' && (
              <PengaturanTemaView
                appData={appData}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
              />
            )}

            {currentView === 'data_demo' && (
              <DataDemoView
                appData={appData}
                readOnly={currentUser.role !== 'admin'}
                onUpdateAppData={handleUpdateAppData}
                onConfirmModal={openConfirmModal}
                onShowToast={showToast}
              />
            )}

            {currentView === 'pengaturan_admin' && (
              <PengaturanAdminView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onUpdateSession={setCurrentUser}
                onShowToast={showToast}
              />
            )}

            {currentView === 'integrasi_mysql' && (
              <IntegrasiMySQLView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
              />
            )}

            {currentView === 'database_traffic' && (
              <DatabaseTrafficView
                appData={appData}
                currentUser={currentUser}
                onShowToast={showToast}
              />
            )}

            {currentView === 'intrusion_detection' && (
              <IntrusionDetectionView
                appData={appData}
                currentUser={currentUser}
                onUpdateAppData={handleUpdateAppData}
                onShowToast={showToast}
                onConfirmModal={openConfirmModal}
              />
            )}

            {currentView === 'cetak_kartu_qr' && (
              <CetakKartuQrView
                appData={appData}
                currentUser={currentUser}
                onShowToast={showToast}
              />
            )}

            {currentView === 'live_chat' && (
              (!(appData.enableLiveChat ?? appData.sekolah?.enableLiveChat ?? true) && currentUser.role !== 'admin') ? (
                <div className="max-w-3xl mx-auto my-8 p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-4 shadow-sm">
                  <div className="w-16 h-16 bg-rose-500/10 text-rose-500 rounded-3xl flex items-center justify-center mx-auto">
                    <MessageSquare className="w-8 h-8" />
                  </div>
                  <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">Fasilitas Live Chat Nonaktif</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
                    Layanan Live Chat saat ini sedang dimatikan oleh Administrator Utama. Silakan hubungi admin secara langsung atau coba lagi nanti.
                  </p>
                  <button
                    type="button"
                    onClick={() => handleNavigate('dashboard')}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
                  >
                    Kembali ke Dashboard
                  </button>
                </div>
              ) : (
                <LiveChatView
                  appData={appData}
                  currentUser={currentUser}
                  onUpdateAppData={handleUpdateAppData}
                  onShowToast={showToast}
                  onConfirmModal={openConfirmModal}
                />
              )
            )}

              </>
            )}
            </React.Suspense>
          </motion.div>
        </main>

        <Footer sekolah={appData.sekolah} />
      </div>

      {/* Live Chat Floating Widget */}
      {(currentUser.role === 'admin' || (appData.enableLiveChat ?? appData.sekolah?.enableLiveChat ?? true)) && (
        <LiveChatWidget
          appData={appData}
          currentUser={currentUser}
          onUpdateAppData={handleUpdateAppData}
          onNavigate={(v) => handleNavigate(v)}
          onShowToast={showToast}
        />
      )}

      {/* Global Toast & Modals */}
      <BackToTop />
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <ConfirmModal state={confirmState} onClose={closeConfirmModal} />
      <GeneralModal
        isOpen={generalModal.isOpen}
        title={generalModal.title}
        onClose={closeGeneralModal}
      >
        {generalModal.content}
      </GeneralModal>

      <ServerQrDisplayModal
        isOpen={isServerQrModalOpen}
        onClose={() => setIsServerQrModalOpen(false)}
        appData={appData}
        onUpdateAppData={handleUpdateAppData}
        onShowToast={showToast}
      />
    </div>
  );
}
